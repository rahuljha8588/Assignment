<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Assignment</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'components/css.php';?>
</head>

<body>

    <div class="main-wrapper">
<?php include 'components/header.php';?>
        <!-- Page Banner Start -->
        <style>
            .hl{
                margin-top: -40px;
            }
        </style>
        <div class="section page-banner hl">

            <img class="shape-1 animation-round" src="assets/images/shape/shape-8.png" alt="Shape">


            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">Privacy Policy</li>
                    </ul>
                    <h2 class="title">Privacy <span> Policy</span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-badge"></i>
                    </div>
                </div>


            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->

        <div class="site-content" style="text-align:left">
    <div class="container">
   <br>

<p><span>The following sets forth the privacy policy for the Global Critique Service&nbsp;&nbsp;Pvt Ltd online panel communities,Global Critique Service&nbsp;Pvt Ltd&nbsp;websites and/or Global Critique Service&nbsp;Pvt Ltd mobile applications (collectively "Application/Services") offered by&nbsp;Global Critique Service&nbsp;Pvt Ltd and its parent, subsidiary and affiliated companies (collectively "Global Critique Service").</span></p>

<p><span>This Privacy Policy sets forth the collection, use and disclosure of personal data or personally identifiable information ("PII") and other information by Global Critique Service&nbsp;in connection with Global Critique Service&nbsp;Services as defined herein and other Global Critique Service&nbsp;and third party activities as defined herein ("Non-Research Activities"). Global Critique Service&nbsp;Services provide you with the opportunity to join a panel, participate in surveys administered by Global Critique Service&nbsp;or by third parties (whether as a panel member or a non-panel member), use the websites associated with the panels, use the Application/Services associated with the panels, and receive and redeem rewards and incentives, including, without limitation, sweepstakes entries, offered in connection with panel membership and/or the completion of surveys (collectively "Services"). Non-Research Activities include, but are not limited to, Global Critique Service marketing Global Critique Service&nbsp;Services and/or third parties marketing their services to you and/or sharing individual and/or aggregate profile data with third parties to develop marketing insights and/or audience/look alike models. Non-Research Activities are described in more detail in this Privacy Policy.</span></p>

<p><span>Your use of Global Critique Service Application/Services is completely voluntary and therefore Global Critique Service&nbsp;processing of your PII in connection with the Application/Services and Non-Research Activities and this Privacy Policy is with your consent.</span></p>

<p><span>Surveys administered by third parties and the data collected in connection therewith are not subject to this Privacy Policy. Registration with, use of, and access to Global Critique Service&nbsp;Services is subject to Global Critique Panel&nbsp;Terms and Conditions. In most cases Global Critique Service&nbsp;is not the sponsor of the survey and the survey instrument, and the survey results or survey data will be owned by the sponsor of the survey.</span></p>

<p><span>All references in this Privacy Policy to "Global Critique Service" include Global Critique Service&nbsp;and its parent, subsidiary and affiliated companies. All references to "us" or "we" refer to Global Critique Service. All PII is stored on servers located in the United States, where Global Critique Service&nbsp;servers are located and accessible globally to Global Critique Service&nbsp;employees and/or agents. For purposes of this policy, respondent shall mean any individual who participates in Global Critique Service&nbsp;Services, including passive data collection and/or participates in the Non-Research Activities described herein. For purposes of this policy, online shall include mobile web browsing,</span></p>

<p><br>
<span>What personal data and other information does the Application/Services collect and how is it used?</span></p>

<p><span>Global Critique Service&nbsp;collects personally identifiable information ("PII") from research participants during and after registration with a panel, including, without limitation, during participation in a survey and in connection with the receipt and redemption of rewards and incentives and/or during the Application/Services registration and download process. You will be asked to provide certain PII and demographic information, including, without limitation, your name, address(es), telephone number(s) (including home, cell, and/or business telephone numbers), email address(es), date of birth, and occupation/education, the unique panelist/respondent identification number we assign to you when you sign up for an account (individually a "UID" and collectively "UIDs"), and racial and gender information. In addition to the collection of PII mentioned above, during and subsequent to the registration process, you may be asked to voluntarily provide or disclose Sensitive Data. "Sensitive Data" means PII that discloses or reveals health and medical conditions, sexual orientation or sexual life, political opinions/views, race/ethnic origin, religious and philosophical beliefs and trade-union membership. Sensitive Data is used to target survey opportunities to you and as otherwise set forth in this Privacy Policy.</span></p>

<p><span>Global Critique Service&nbsp;collects PII, Sensitive Data and demographic information from non-panel members prior to and during participation in a survey.</span></p>

<p><span>Global Critique Service&nbsp;provides its clients and/or its advertising partners with information about your device, including but not limited to, the device's IDFA or Advertising ID and interactions with the Application/Services with your consent. Global Critique Service, the clients and/or ad partners may use this information to facilitate Global Critique Service&nbsp;surveys, for marketing of Global Critique Service&nbsp;products and services to you, for unrelated interest-based advertising, to link your device to additional data about you and/or your device available from third party data management platforms and data providers/brokers and/or to validate certain information you provide about yourself and/or your device. Click here to learn more about some of our ad partners, including how to subsequently opt-out.</span></p>

<p><span>Additional information you submit.</span></p>

<p><span>You may submit, upload or transmit content or material, including, without limitation, photos, videos, and/or any other similar or related content or material which may include your PII ("User Content"), for example, when completing surveys. PII included in User Content shall be collected, used and disclosed as set forth in this Privacy Policy. User Content should not include audio, video, images, or the likeness of anyone other than you.</span></p>

<p><span>Information collected through automated means:</span></p>

<p><span>The Application/Services also collect certain information automatically, such as information about your device and device capabilities, including, without limitation, the device operating system, the other applications on your device, IP address, device network provider, device type, time zone, network status, browser type, browser identifier, unique device identification number (such as identifiers for analytics or advertising), network provider user ID (a number uniquely allocated to you by your network provider), Media Access Control (MAC) address, International Mobile Equipment Identity, location and other information that alone or in combination may be used to uniquely identify your device. Specific examples of this data and the technology that collects it are below:</span></p>

<p><span>Geo-location data. The Application/Services will request your permission to obtain geo-location information from your mobile device, and such geo-location information may be provided by the Application/Services at any time, whether the Application/Services is open or not. If you consent to sharing your geo-location data, in addition to the uses set forth under "Global Critique Service&nbsp;use of information" below, Global Critique Service&nbsp;will also use your location information to offer you the option to participate in location-based surveys and market research and/or to share such geolocation data with third party clients to demonstrate certain location and/or traffic patterns of Application/Services participants. In addition, Global Critique Service&nbsp;may share your geo-location data with third party vendors to generate surveys for market research and for other research from aggregated location patterns. Please visit this Privacy Policy for a description of how our partner uses the geo-location data.</span></p>

<p><span>Geo-location data also may be used by ad networks to provide you with location-based advertising. The ad networks' use of data, and how to opt out, are described in more detail below.</span></p>

<p><span>If you no longer wish to share your geo-location data through your device, please change the privacy settings in your device for the Application/Services.</span></p>

<p><span>Application/Services and functionality. Global Critique Service&nbsp;may request access to certain applications and/or functionality available on or through your device for use in connection with the Application/Services and the Services. Access shall be requested via push notification or other alerts and access will only be granted with your consent. If you consent, you may subsequently opt-out by changing your settings on the device.</span></p>

<p><span>Social media information. You may also be offered the opportunity to access the Application/Services through third party social media platforms. If you select such option, Global Critique Service may collect certain profile information stored in your social media platform account.</span></p>

<p><span>Cookies and Similar Technology. Cookies are small files that store certain data on a device. Session cookies expire when you close your browser. Persistent cookies remain on your device until deleted or once they reach a defined expiration date. You may set your browser to notify you when you receive a cookie. Additional geographic and demographic data such as the Audience Measurement Data (as defined below) may be shared with third parties and associated with a cookie placed on your device.</span></p>

<p><span>First party and third party cookies and other similar or related technology and device identifiers (e.g., IDFAs, AAIDs, etc.) may be placed, written, set, and/or read for several purposes including, without limitation, to provide a better survey experience, quality control, validation, to enable or facilitate survey participation, tracking of completed surveys or other completed actions, for fraud detection and/or prevention, online ad effectiveness research, website tracking and audience measurement, to develop audience insights and/or look-alike models in connection with marketing campaigns, and for the purpose of targeting advertisements and other content to individuals, subject to your consent where required by applicable law. However, for certain cookies and/or similar or related technology, if you decide not to accept cookies, you will not be able to use the Application/Services.</span></p>

<p><span>For more information on the types of cookies we use, the purposes for which we use information collected via cookies, please see our Cookie Consent Tool.</span></p>

<p><span>Log Files. The Application/Services may automatically gather and store certain information, including, without limitation, data available from your web browser, including, without limitation, IP Address, browser type, internet service provider, referring/exiting pages, operating system, date/time stamp, and click stream data in log files.</span></p>

<p><span>Digital Fingerprinting. Generally, digital fingerprinting assigns a unique identifier to your device based upon the device's technical settings, characteristics, and IP Address. Global Critique Service uses digital fingerprinting technology for quality control and validation purposes and fraud detection and/or prevention, including, without limitation, identifying duplicate or fraudulent respondents. Global Critique Service may implement and use digital fingerprinting directly or through a third party vendor with your consent where required by applicable law.</span></p>

<p><span>Watermarking. Generally, watermarking involves placing a technology or file on your device to identify that it has previously been used to register with or access the Application/Services or the Services. Watermarking is used for quality control and validation purposes and fraud detection and/or prevention purposes. Global Critique Service may engage in watermarking activities directly or through a third party vendor with your consent where required by applicable law. In some cases, we may use information collected through automated means, along with other information, to recognize users (or households) across platforms or across devices, such as smartphones, computers, tablets or related browsers, for the purposes described in this Privacy Policy.</span></p>

<p><span>Information collected from third parties</span></p>

<p><span>Global Critique Service may obtain PII, behavioral and/or demographic information from third parties, including, without limitation, data management platforms, ad networks, information service bureaus, other sample suppliers and/or social media platforms. Global Critique Service may use the PII, behavioral and/or demographic data received from these third parties for various purposes, including, without limitation, data validation, data append, developing marketing insights and look alike models, fraud detection purposes, and/or sending you a one-time email to invite you to participate in a survey and/or join a Panel. In addition, geolocation data, including information regarding retail and other commercial enterprises you may visit while the geolocation feature is enabled, may be appended to your panel profile and/or shared with Global Critique Service's clients if you elected to opt in to the geolocation services.</span></p>

<p><span>How does Global Critique Service use the information it collects?</span></p>

<p><span>Global Critique Service's use of information:</span></p>

<p><span>In addition to the purposes described above, Global Critique Service uses personal data collected through the Application/Services as follows: (i) to communicate with you regarding your membership with a survey panel(s) owned by Global Critique Service; (ii) to communicate with you regarding your participation in a survey(s); (iii) to tailor survey opportunities to you and to arrange for advertisements to be displayed to you outside the Application/Services for the purposes of facilitating the completion of advertisement recall surveys; (iv) to send you notifications of survey opportunities; (v) to comply with any and all legal obligations, including, without limitation, tax obligations; (vi) to administer and manage Global Critique Service's reward and incentive programs and fulfill your requests for rewards and incentives; (vii) to facilitate your entry into Global Critique Service's sweepstakes and promotions and communicate with you regarding such entries; (viii) to update Global Critique Service's records; (ix) to comply with any data suppression obligations or requirements; (x) for fraud detection and/or prevention purposes; (xi) to link your device and/or profile to additional information available about you and/or your device available from data management platforms ("DMP"); (xii) to market Global Critique Service products/services to you; (xiii) to enable third parties to market their products/services to you; (xiv) to enable Global Critique Service or third parties to develop marketing insights and/or audience/look alike models; (xv) to validate the profile information you provided to us; and/or (xvi) as otherwise permitted pursuant to this Policy or as otherwise authorized by you. Global Critique Service may use information collected in the context of the Application/Services in connection with other survey panels that Global Critique Service administers and/or in connection with Non-Research Activities. With respect to the linking of Application/Services data to third party DMP data, Global Critique Service uses such data itself and/or permits Global Critique Service's clients and/or the DMP itself to use such data to provide you with survey opportunities, to measure advertising effectiveness (as described in more detail below), to segment audiences; to design advertising campaigns using "look alike" cohort groups based on survey and third party data; and/or to market such third party's products/services to you.</span></p>

<p><span>Retargeting. Global Critique Service may from time-to-time engage a third party or third parties to either display advertising on an Global Critique Service website(s) or to manage Global Critique Service's advertising on other websites (for example on social media sites). Global Critique Service's third party partner(s) may use technologies such as cookies or identifying data elements. Including but not limited to your IDFA or Advertising ID to gather information about your activities on Global Critique Service's website(s) and/or on other websites in order to: (i) provide you with advertising about Global Critique Service and its services and/or (ii) assist Global Critique Service in developing marketing and advertising campaigns designed to target individuals who have a social and demographic profile similar to your social and demographic profile. If Global Critique Service is conducting a re-targeting program and you wish to not participate in this re-targeting program, please opt-out via the applicable cookie opt-out process set forth in this Privacy Policy or in Global Critique Service's separate cookie notice, by modifying your IDFA or Advertising ID and/or by unsubscribing within the advertisement itself.</span></p>

<p><span>Audience Insights/Look-alikes. Global Critique Service and/or third parties may use Personal Data and/or may link Personal Data to a third-party cookie to develop audience insights and/or look-alike models in connection with marketing campaigns.</span></p>

<p><span>Online Advertising Effectiveness. In connection with Global Critique Service's online ad effectiveness program, you can participate in surveys regarding ads, promotions, content, campaigns, and/or websites that Global Critique Service is testing for its clients. To facilitate the completion of these surveys, Global Critique Service's clients may write, set, or read cookies, locally shared/stored objects, flash cookies and/or any other related technology (each a "Third Party Technology" and collectively the "Third Party Technologies"). The Third Party Technologies may be written, set or read in various locations, including, without limitation, Global Critique Service's servers or systems. If you participate, your UID will be stored in or associated with the Third Party Technology to allow you to be re-contacted about the online ad or promotion and Global Critique Service's client will use the Third Party Technology to determine whether you have seen, clicked on, or otherwise interacted with the online ad or promotion. If you have interacted with the online ad or promotion, Global Critique Service's client will send your UID and the specific survey to Global Critique Service and Global Critique Service will provide you with the opportunity to complete the survey.</span></p>

<p><span>Audience Measurement Data. In addition to the use and sharing of Audience Measurement Data (as defined below) in connection with online advertising effectiveness research, as such research is described above, Global Critique Service may share your UID and data previously collected by Global Critique Service, including, without limitation, age, gender, income, number of people in your household, education/education level, and employment status, ("Audience Measurement Data"), to third parties, including, without limitation, Global Critique Service's subcontractors, partners, and/or clients for the purpose of audience measurement reporting on the content, advertisements, campaigns, and websites that you visit, view, and/or click on. The Audience Measurement Data will be used in connection with online advertising effectiveness research, and to assist in the creation, development, and implementation of websites, online advertisements, and other Internet and digital media features, functionality, and campaigns. Audience Measurement Data may be shared in a single summary form (i.e. individual respondent level) or aggregate summary form (i.e. group of respondents).</span></p>

<p><br>
<span>What communications will I receive through the Application/Services or relating to the Services?</span></p>

<p><span>Global Critique Service may contact you to participate in surveys via "push" notifications or SMS/text messages if you expressly agree to receive such communications.</span></p>

<p><span>In addition, Global Critique Service and/or its agents or vendors on behalf of Global Critique Service will send email communications to you regarding survey invitations, survey participation, reward or incentive information, inquiries and redemption, newsletters, notices required to be provided hereunder or by law, sweepstakes or promotion entries, notice of winning a sweepstakes or promotion, and in response to inquiries from you.</span></p>

<p><span>Where you provide Global Critique Service with your telephone number(s), Global Critique Service, its clients and/or its Subcontractors may also contact you by telephone in relation to your account, including, without limitation: (i) surveys you have or are participating in; (ii) reward or incentive information, inquiries and redemption; (iii) sweepstakes or promotion entries and prize fulfillment; (iv) responding to your queries; (v) notices under this Privacy Policy; (vi) additional survey invitations and/or opportunities; and/or (vii) to validate profile information you have provided to us.</span></p>

<p><span>Does Global Critique Service share personal data and other information collected through the Application/Services with third parties?</span></p>

<p><span>Pursuant to applicable law, Global Critique Service may disclose or transfer personal data and other information collected through the Application/Services to third parties as follows:</span></p>

<p><span>(i) With your consent;</span></p>

<p><span>(ii) In response to a subpoena or an order of a court or government agency;</span></p>

<p><span>(iii) To establish, exercise, or defend legal claims of an individual or Global Critique Service, including in order to protect the safety of an individual or to protect Global Critique Service's rights and/or property;</span></p>

<p><span>(iv) Between various Global Critique Service panels, if you sign up for more than one Global Critique Service panel;</span></p>

<p><span>(v) To a parent, subsidiary, or affiliate of Global Critique Service: (1) in the event of a reorganization or restructuring; or (2) for use and processing in accordance with this Policy or as authorized by you;</span></p>

<p><span>(vi) To authorized agents and/or subcontractors of Global Critique Service and/or of Global Critique Service's clients, who are providing services, including, without limitation, data append services, data validation services, fraud detection and/or prevention services, database matching services, coding services, and reward, incentive, and sweepstakes related services. In connection with the sharing of personal data and other information with subcontractors as set forth in (vi) above, such subcontractors may use such data to improve or enhance their services, in which event they are acting as data controllers or data owners and not as subcontractors engaged by Global Critique Service. For a list of the subcontractors acting as data controllers or data owners of your data and their privacy policies, please click here.</span></p>

<p><span>(vii) To a client for limited market research related uses including, without limitation, modeling, validation, data append, database segmentation, and reward, incentive, or sweepstakes redemption, fulfillment, and/or entry;</span></p>

<p><span>(viii) In connection with a change of ownership or control, including, without limitation, a merger or an acquisition of any or all of Global Critique Service's business assets, provided that the party receiving or acquiring the personal data agrees to use, protect, and maintain the security, integrity, and confidentiality of personal data in accordance with this Policy;</span></p>

<p><span>(ix) to a client or to such client's customer in the event Global Critique Service or a third party believes that you have or may violate the intellectual property rights of a third party;</span></p>

<p><span>(x) to a client or to such client's customer in the event Global Critique Service or a third party believes that you have violated the Terms of Service;</span></p>

<p><span>(xi) to a third party, which shall include both Global Critique Service research clients and third parties that engage in Non-Research Activities to enable such third party to develop marketing campaigns, audience insights, look-alike models and/or to market such third party's products/services to you; and</span></p>

<p><span>(xii) As otherwise permitted pursuant to this Policy.</span></p>

<p><span>In addition to the foregoing, if you enroll through a third party with whom Global Critique Service has a contractual relationship and/or from an email sent from a third party company proposing you to join our Application/Services (collectively "Program Partner"), Global Critique Service may share select enrollment information with the Program Partner who invited you into the program, which can include your full name, post or zip code, and your email address. You acknowledge that our Program Partner may collect, use, and disclose that information in accordance with their privacy policy. Please note that Global Critique Service will not be responsible for and will not be liable for our Program Partner's actions concerning your information or for any Program Partner's privacy practices when you are dealing directly with them.</span></p>

<p><span>Please note, Global Critique Service may allow a client to collect PII directly from respondents. The disclosure is voluntary and, prior to collection, the client is required to enter into a written agreement with Global Critique Service, which, among other things, limits use of the PII.</span></p>

<p><span>Global Critique Service may license certain PII to third parties (e.g., data brokers, data aggregators, etc.) for their own Non-Research Purposes, including, without limitation, the licensing of individual-level and/or aggregated-level data (e.g., product and/or service purchasing or usage activity, social media activity, website visitation data, internet search history, etc.) for the development of audience insights and/or look-alike models, for the purpose of sale of such data to the third party's clients/customers for the purpose of performing analytics and providing marketing intelligence and/or to enable such third party to market its products/services to you.</span></p>

<p><span>Additionally, UIDs and information collected by automated means are provided to third parties, including, without limitation, clients, partners, agents and/or vendor for the purposes of identifying respondents for re-contact surveys or communications, fraud detection and/or prevention, database matching, data validation, data append, coding, data segmentation, and reward, incentive, and/or sweepstakes or promotion related services.</span></p>

<p><span>In connection with your survey data, Global Critique Service or the client may associate certain demographic attributes to you. Global Critique Service may share with third parties, including but not limited to clients, the geographic and/or demographic data Global Critique Service collects from you during enrolment or through certain profile questions Global Critique Service may ask you. Such data may be shared with third parties on an individual respondent level or aggregate summary form (i.e. a group of respondents). If you voluntarily disclose personal data in connection with your survey data and responses, and Global Critique Service collects the survey data and responses, Global Critique Service will transfer the survey data and responses, UID and the voluntarily disclosed personal data to the relevant Global Critique Service client.</span></p>

<p><span>How can I opt-out of certain data collection and/or use?</span></p>

<p><span>There are multiple opt-out options for users of this Application/Services.</span></p>

<p><span>You can stop all collection of personal data and other information by the Application/Services by uninstalling the Application/Services and/or terminating your participation in the panel(s). You may use the standard uninstall processes available as part of your mobile device or via the mobile application marketplace or network and/or you may cancel your panelist account on the panel Site. Please note that if you delete the Application/Services, but maintain a profile with one of Global Critique Service's websites, we may still collect personal data and other data from you through our site(s). Uninstalling the Application/Services will not delete all information collected by Global Critique Service prior to uninstalling the Application/Services. To delete all information collected by Global Critique Service please contact Global Critique Service as set forth below.</span></p>

<p><span>Six months following termination of your account, inactivity of your account and/or the date upon which you uninstall the Application/Services, Global Critique Service may transfer your PII to a third party data broker and/or data management platform for purposes of resale/reuse by such third party. If you do not wish for your PII to be used for Non-Research Activities and/or if you do not consent to Global Critique Service sharing your PII with third parties after termination of your account and/or removal of the Application/Services from your device, please contact us at&nbsp;</span></p>

<p><span>For iOS Opt-out of location data</span></p>

<p><span>You may, at any time, opt-out from enabling the Application/Services to access your location data by:</span></p>

<p><span>Touching or selecting the settings icon for the device;<br>
Once in the settings icon, touch or select Location Services; and<br>
Once in Location Services, you can use the individual slider for the Application/Services, to turn off location services.</span></p>

<p><span>Note: If you turn off Location Services, you will be prompted to turn on Location Services the next time the Application/Services tries to use this feature.</span></p>

<p><span>For Android Opt out of location data</span></p>

<p><span>You may, at any time, opt-out from enabling the Application/Services to access your location data by:</span></p>

<p><span>Touching the ABOUT button on the top right of the navigation bar<br>
Once in the ABOUT dialog, you can toggle on/off Location Services via a switch labeled: "Access to my location"</span></p>

<p><span>For iOS Opt-out of push notifications</span></p>

<p><span>You may opt-out of push notifications for the Application/Services by:</span></p>

<p><span>Touching or selecting the settings icon for the device;<br>
Once in the settings icon, touch or select notifications;<br>
If push notifications are turned on, there will be a list of icons, touch or select the icon for the Application/Services; and<br>
From this screen, you will be able to modify the push notification settings for the Application/Services.</span></p>

<p><span>For Android Opt-out of push notifications</span></p>

<p><span>You may opt-out of push notifications for the Application/Services by:<br>
Access the Settings for the device.<br>
From within Settings, locate the Apps setting.<br>
Once in Apps, locate the relevant application (QuickThoughts or iPoll), and select it.<br>
Locate a checkbox labeled "Show notifications" and toggle it based on your preference.</span></p>

<p><span>Opt-out of email communications</span></p>

<p><span>You may opt-out of email communications by clicking the unsubscribe link in any email you receive from us or contacting us as set forth below.</span></p>

<p><span>Opt-out of sharing social media platform profile data</span></p>

<p><span>You may opt-out of sharing social media platform profile data by changing your preference/profile settings with the social media platform regarding the sharing of data with third parties or removing the Application/Services from your social media profile.</span></p>

<p><span>Opt out of use of the advertising identifier assigned to your smartphone/device</span></p>

<p><span>You may change the advertising identifier assigned to your device at any time.</span></p>

<p><span>Ad network opt-out</span></p>

<p><span>The ad networks that collect information through the Application/Services for use in facilitating surveys and providing interest-based advertising offer certain opt-out mechanisms. To opt-out, follow the instructions for each ad network at the links provided below. If you opt-out, you will not be able to participate in our surveys about ads and promotions.</span></p>

<p><span>Ad network<br>
Admob by Google<br>
Flurry</span></p>

<p><br>
<span>Can I stop Global Critique Service from tracking my online activities?</span></p>

<p><span>Do Not Track ("DNT") is a preference in your browser that you can set to notify websites that you visit that you do not want the websites to collect certain information about you. Global Critique Service does not respond to DNT signals. If you object to Global Critique Service's practice with regards to DNT signals, you may opt-out from participation or use of Global Critique Service's services as described below.</span></p>

<p><span>In connection with Global Critique Service's online ad effectiveness program, Global Critique Service permits Global Critique Service's subcontractors, partners and/or clients to drop, set, and/or write Third Party Technologies for the purpose of facilitating audience measurement and ad recall survey activities. Global Critique Service is not responsible for any third party's compliance with or response to DNT signals. To learn more about Global Critique Service's online ad effectiveness program, please review the Cookies section of this Privacy Policy.</span></p>

<p><span>How long do you keep my personal data and other information?</span></p>

<p><span>Global Critique Service will retain personal data and other information relating to your use of the Application/Services and/or the Services for as long as you have the Application installed and/or use the Application/Services and for up to one (1) year thereafter or such other period as may be required or permissible by law. Six months following your inactivity with the panel Sites and/or uninstalling the Application/Services, Global Critique Service may transfer your PII to a third party data broker and/or data management platform for purposes of resale/reuse by such third party.</span></p>

<p><span>How can I access the personal data and other information the Application/Services has collected about me?</span></p>

<p><span>You have the right to review, correct, and delete your personal data, subject to applicable law. You may contact us with such a request using the contact details provided below.</span></p>

<p><span>Does the Application/Services collect data from minors under thirteen (13) years of age?</span></p>

<p><span>The Application/Services is not designed for, or intended for use by, any individual under the age of thirteen (13). We do not knowingly collect personal data from children under the age of thirteen (13), and if we became aware that we have inadvertently collected personal data from a child under the age of thirteen (13), we will undertake reasonable commercial efforts to delete such personal data.</span></p>

<p><span>What security is available for the personal data and other information collected through the Application/Services?</span></p>

<p><span>Global Critique Service maintains an appropriate level of technical, administrative, and physical safeguards to protect personal data and other information disclosed or collected by Global Critique Service. Global Critique Service reviews, monitors, and evaluates its privacy practices and protection systems on a regular basis. Despite the safeguards we implement, transmissions over the Internet and/or a mobile network are not totally secure and Global Critique Service does not guarantee the security of online transmissions. Global Critique Service is not responsible for any errors by individuals in submitting personal data to Global Critique Service.</span></p>

<p><span>FOR CALIFORNIA RESIDENTS:</span></p>

<p><span>Your Rights Under the California Consumer Protection Act of 2018 ("CCPA")</span></p>

<p><span>Pursuant to the California Consumer Protection Act of 2018 ("CCPA"), and subject to certain exceptions and limitations, Californians can contact Global Critique Service to exercise the rights described below with respect to certain personal information that Global Critique Service holds about them. To the extent those rights apply to you, they are described below. Global Critique Service also handles certain personal information on behalf of Global Critique Service customers. You should contact those customers to exercise any rights you may have with respect to that personal information.</span></p>

<p><span>Right to Know About Personal Information Collected, Disclosed, or Sold</span></p>

<p><span>You have the right to request that we provide you with details about the personal information we collect, use, disclose and sell. You can submit a verifiable consumer request by clicking here. You can also submit your request via our toll-free number +918287759646. Global Critique Service reserves the right to verify your identity to our satisfaction, including by asking you to log into your account if you have one.</span></p>

<p><span>You are entitled to receive the following:</span></p>

<p><span>The categories of your personal information that Global Critique Service has collected in the preceding 12 months<br>
The categories of sources from which that information was collected<br>
The business/commercial purpose for the collection or selling<br>
The categories of third parties with whom Global Critique Service shares personal information<br>
The specific pieces of personal information Global Critique Service has collected about you (subject to some exceptions)</span></p>

<p><span>Because Global Critique Service has disclosed or sold (as those words are defined in the CCPA) personal information to third parties in the last 12 months, you are also entitled to receive:</span></p>

<p><span>The categories of personal information that Global Critique Service has disclosed or sold in the past 12 months</span></p>

<p><span>Right to Request Deletion of Personal Information</span></p>

<p><span>You have the right to request deletion of the personal information we have collected about you (subject to some exceptions). You can submit your request as described above, and we reserve the right to conduct the verification described above.</span></p>

<p><span>Right to Non-Discrimination for the Exercise of a Consumer’s Privacy Rights</span></p>

<p><span>You have the right not to receive unlawful discriminatory treatment by Global Critique Service for the exercise of your privacy rights under the CCPA.</span></p>

<p><span>Right to Opt-Out of Sale of Personal Information</span></p>

<p><br>
<span>List of Categories of Personal Information to be Collected and May Have Been Sold or Disclosed</span></p>

<p><span>Categories of Personal Information Collected</span></p>

<p><span>Global Critique Service collects personal information from research participants during and after registration with a panel, including, without limitation, during participation in a survey and in connection with the receipt and redemption of rewards and incentives and/or during the Application/Services registration and download process.</span></p>

<p><span>The categories of personal information we may collect include:</span></p>

<p><span>"Identifiers" such as<br>
Name<br>
Address(es)<br>
Telephone number(s) (including home, cell, and/or business telephone numbers)<br>
Email address(es)<br>
Date of birth<br>
Internet Protocol address<br>
Unique device identification number (such as identifiers for analytics or advertising)<br>
Network provider user ID (a number uniquely allocated to you by your network provider)<br>
Media Access Control (MAC) address<br>
International Mobile Equipment Identity<br>
Unique cookie identifiers<br>
Information about your device (e.g., device operating system, the other applications on your device, device network provider, device type, time zone, network status, browser type, browser identifier and other information that alone or in combination may be used to uniquely identify your device)<br>
Geolocation<br>
Cookies and similar technology<br>
Social media information<br>
Log files<br>
Digital fingerprinting<br>
Watermarking<br>
Browsing activity<br>
Other behavioral information<br>
Professional or employment-related information, including occupation<br>
Education information<br>
Additional content/material you submit, including photos, videos and/or similar content<br>
Characteristics of potentially protected classifications under California, federal or international law (e.g., health and medical conditions, sexual orientation or sexual life, political opinions/views, race/ethnic origin, gender, religious and philosophical beliefs and trade-union membership)<br>
Other medical information<br>
Demographic information</span></p>

<p><br>
<span>Auditing related to a current interaction with you and concurrent transactions, including, but not limited to, counting ad impressions to unique visitors, verifying positioning and quality of ad impressions, and auditing compliance with the CCPA and other standards;<br>
Detecting security incidents, protecting against malicious, deceptive, fraudulent, or illegal activity, and prosecuting those responsible for that activity;<br>
Debugging to identify and repair errors that impair existing intended functionality;<br>
Short-term, transient uses;<br>
Performing or using services, including maintaining or servicing accounts, providing customer service, processing or fulfilling orders and transactions, verifying customer information, processing payments, providing financing, providing or using advertising or marketing services, providing or using analytic services, or providing or using similar services;<br>
Undertaking internal research for technological development and demonstration;<br>
Undertaking activities to verify or maintain the quality or safety of services and devices, and to improve, upgrade, or enhance services and devices; and<br>
Facilitating the operational purposes of Global Critique Service or our service providers.</span></p>

<p><span>Categories of Personal Information that May Have Been Sold</span></p>

<p><span>Global Critique Service sold all of the above categories of personal information in the last 12 months.</span></p>

<p><span>Categories of Personal Information that Were Disclosed</span></p>

<p><span>Global Critique Service disclosed all of the above categories of personal information in the last 12 months.</span></p>

<p><span>Who can I contact with questions about this Policy?</span></p>

<p><span>If you wish to:</span></p>

<p><span>- receive a copy of the information we hold about you;</span></p>

<p><span>- communicate an opt-out request to Global Critique Service;</span></p>

<p><span>- request access to, or the correction, blocking or deletion of, your personal data;</span></p>

<p><span>- make a complaint about our privacy practice;</span></p>

<p><span>-opt out of certain uses of your PII;</span></p>

<p><span>Global Critique Service's Legal Department is responsible for Global Critique Panel&nbsp;compliance with this Policy.</span></p>

<p><span>Global Critique Service has appointed a local coordinator for privacy / Data Protection Officer (DPO). To get in touch with him/her for any information regarding the processing of personal data by globalcritiquepanel, including a list of its data processors, please contact : Johnsmith@globalcritiqueservice.com</span></p>

<p>&nbsp;</p>
   <style type="text/css">.contentAndLinks-content img:first-child {
    display:none!important;
}
   br:nth-child(2), br:nth-child(3){
    display:none!important;
  }
    
    /*Hide title tag start*/
  .contentAndLinks-title {
    display: none;
  }
  /*Hide title tag end*/
    
    table br {
        display: none;
    }
    
    .office th, .office td {
    width: 210.7pt; 
    border: 1pt solid windowtext; 
    padding: 8.6pt;
    }
  
  th {
    width: 120.7pt; 
    border: 1pt solid windowtext; 
    padding: 8.6pt;
    }
  
td {
    width: 120.7pt; 
    border: 1pt solid windowtext; 
    padding: 8.6pt;
    }
 .cotype p {
            font-weight: 600;
        }
    @media screen and (max-width: 700px) {
       .office table, .office thead, .office tbody, .office th, .office td, .office tr, table, thead, tbody, th, td, tr { 
		display: block; 
             width: auto;
            text-align: left;
	}
        table br {
        display: block;
    }
        
       .office td, td {
            border: none;
        }

       .office th , th{
            display: none;
        }
        .cotype p {
            font-weight: 500;
        }
        
        table td:before, .office table td:before {
            content: attr(data-label);
            float: left;
            font-size: 20px;
            font-weight:600;
            line-height: 25px;
        }
        
       .office th, .office td,  td, th {
            padding: 3.6pt;
        }
        tr:nth-child(even), .office tr:nth-child(even){background-color: #E6E6E6}
    }
  
  h1 {
    font-size: 35px;
  }
</style></div>
  </div>

 <?php include 'components/footer.php';?>

    </div>
            <!--Back To Start-->
            <a href="#" class="back-to-top">
            <i class="icofont-simple-up"></i>
        </a>
        <!--Back To End-->
<?php include 'components/js.php';?>

</body>


</html>