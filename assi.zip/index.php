<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Assignment</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'components/css.php';?>
</head>

<body>

    <div class="main-wrapper">
<?php include 'components/header.php';?>



        <!-- Slider Start -->
        <style>
            .padding-top{
                padding-top: 0px;
            }
            .asd{
                height: 600px;
            }
            .asp{
                margin-bottom: 51px;
            }
        </style>
        <div class="section slider-section asd " >

        

            <div class="container asp" >

                <!-- Slider Content Start -->
                <div class="slider-content">
                    <h1 class="main-title">Assignment Help in  <span>India </span></h1>
                    <p>It has survived not only five centuries but also the leap into electronic typesetting.</p>
                    <a class="btn btn-primary btn-hover-dark" href="#">Start A Course</a>
                </div>
                <!-- Slider Content End -->

            </div>

            <!-- Slider Courses Box Start -->
            <div class="slider-courses-box">

                <img class="shape-1 animation-left" src="assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-open-book"></i>
                        <span class="count">1,235</span>
                        <p>courses</p>
                    </div>
                </div>

                <img class="shape-2" src="assets/images/shape/shape-6.png" alt="Shape">

            </div>
            <!-- Slider Courses Box End -->

            <!-- Slider Rating Box Start -->
            <div class="slider-rating-box">

                <div class="box-rating">
                    <div class="box-wrapper">
                        <span class="count">4.8 <i class="flaticon-star"></i></span>
                        <p>Rating (86K)</p>
                    </div>
                </div>

                <img class="shape animation-up" src="assets/images/shape/shape-7.png" alt="Shape">

            </div>
            <!-- Slider Rating Box End -->

            <!-- Slider Images Start -->
            <div class="slider-images">
                <div class="images">
                    <img src="assets/images/slider/slider-1.png" width="500px" alt="Slider">
                </div>
            </div>
            <!-- Slider Images End -->

            <!-- Slider Video Start -->
            <div class="slider-video">
                <img class="shape-1" src="assets/images/shape/shape-9.png" alt="Shape">

                <div class="video-play">
                    <img src="assets/images/shape/shape-10.png" alt="Shape">
                    <a href="https://www.youtube.com/watch?v=BRvyWfuxGuU" class="play video-popup"><i class="flaticon-play"></i></a>
                </div>
            </div>
            <!-- Slider Video End -->

        </div>
        <!-- Slider End -->

            <!-- About Start -->
            <div class="section">

                <div class="section-padding-02 mt-n10">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
    
                                <!-- About Images Start -->
                                <div class="about-images">
                                    <div class="images">
                                        <img src="assets/images/about.jpg" alt="About">
                                    </div>
    
                                    <div class="about-years">
                                        <div class="years-icon">
                                            <img src="assets/images/logo-icon.png" alt="About">
                                        </div>
                                        <p><strong>28+</strong> Years Experience</p>
                                    </div>
                                </div>
                                <!-- About Images End -->
    
                            </div>
                            <div class="col-lg-6">
    
                                <!-- About Content Start -->
                                <div class="about-content">
                                    <h2 class="main-title">About<span> Website</span></h2>
                                    <p>Lorem Ipsum has been the industr’s standard dummy text ever since unknown printer took galley type and scmbled make type specimen book. It has survived not only five centuries.</p>
                                    <p>Lorem the industr’s standard dummy text ever since   the industr’s standard dummy text ever since   the industr’s standard dummy text ever since  Ipsum has been the industr’s standard dummy text ever since unknown printer took galley type and scmbled make type specimen book. It has survived not only five centuries.</p>
                                    <a href="#" class="btn btn-primary btn-hover-dark">Start A Course</a>
                                </div>
                                <!-- About Content End -->
    
                            </div>
                        </div>
                    </div>
                </div>
    
               
    
            </div>
            <!-- About End -->

                <!-- How It Work End -->
<div class="section section-padding mt-n1">
    <div class="container">

        <!-- Section Title Start -->
        <div class="section-title shape-03 text-center">
            <h2 class="main-title">Free Value Added Services for Academic <span><br>Excellence ?</span></h2>
        </div>
        <!-- Section Title End -->

        <!-- How it Work Wrapper Start -->
        <div class="how-it-work-wrapper">

            <!-- Single Work Start -->
            <div class="single-work" data-aos="fade-right">
                <img class="shape-1" src="assets/images/shape/shape-15.png" alt="Shape">

                <div class="work-icon">
                    <i class="flaticon-transparency"></i>
                </div>
                <div class="work-content">
                    <h3 class="title">Draft Feedback</h3>
                    <p>It has survived not only centurie also leap into electronic.</p>
                </div>
            </div>
            <!-- Single Work End -->


        


             <!-- Single Work Start -->
             <div class="single-work" data-aos="fade-up">
                <img class="shape-2" src="assets/images/shape/shape-15.png" alt="Shape">

                <div class="work-icon">
                    <i class="flaticon-forms"></i>
                </div>
                <div class="work-content">
                    <h3 class="title">Expert Consultation</h3>
                    <p>It has survived not only centurie also leap into electronic.</p>
                </div>
            </div>
            <!-- Single Work End -->
      

            <!-- Single Work Start -->
            <div class="single-work" data-aos="fade-left">
                <img class="shape-3" src="assets/images/shape/shape-16.png" alt="Shape">

                <div class="work-icon">
                    <i class="flaticon-badge"></i>
                </div>
                <div class="work-content">
                    <h3 class="title">Digital Library</h3>
                    <p>It has survived not only centurie also leap into electronic.</p>
                </div>
            </div>
            <!-- Single Work End -->


            
        </div>

</div>
</div>
<!-- How It Work End -->
        <!-- Download App Start -->
        <div class="my-5 section section-padding download-section">

            <div class="app-shape-1"></div>
            <div class="app-shape-2"></div>
            <div class="app-shape-3"></div>
            <div class="app-shape-4"></div>

            <div class="container">

                <!-- Download App Wrapper Start -->
                <div class="download-app-wrapper mt-n6">

                    <!-- Section Title Start -->
                    <div class="section-title section-title-white">
                        <h5 class="sub-title">Impeccable Quality Assignments</h5>
                        <h2 class="main-title">Greatness never settles for average</h2>
                    </div>
                    <!-- Section Title End -->

                    <img class="shape-1 animation-right" src="assets/images/shape/shape-14.png" alt="Shape">

                    <!-- Download App Button End -->
                    <div class="download-app-btn">
                        <ul class="app-btn">
                            <div class="call-to-action-btn">
                                <a class="btn btn-outline-light btn-hover-light " href="contact.html">Drop Information</a>
                            </div>
                        </ul>
                    </div>
                    <!-- Download App Button End -->

                </div>
                <!-- Download App Wrapper End -->

            </div>
        </div>
        <!-- Download App End -->

       


        <div class="section-padding-02 mt-n6">
            <div class="container">

                <!-- About Items Wrapper Start -->
                <div class="about-items-wrapper">
                    <div class="section-title shape-03 text-center">
                        <h2 class="main-title">Exceptional Online Assignment Help in  <span><br>India<span></h2>
                    </div>
                    <div class="row">
                        <div  data-aos="zoom-in" data-aos-delay="100"  class="col-lg-4">
                            <!-- About Item Start -->
                            <div style="box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;"class="about-item">
                                <style>
                                    .pll{
                                        display: flex;
    flex-direction: column;
                                    }
                                </style>
                                <div class="item-icon-title pll">
                                    <div class="item-icon">
                                        <i class="flaticon-tutor"></i>
                                    </div>
                                    <div class="item-title">
                                        <h3 class="title">Top Instructors</h3>
                                    </div>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dumy text since the when took and scrambled to make type specimen book has survived.</p>
                            </div>
                            <!-- About Item End -->
                        </div>  
                         <div  data-aos="zoom-in" data-aos-delay="200"  class="col-lg-4">
                            <!-- About Item Start -->
                            <div style="box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;"class="about-item">
                                <style>
                                    .pll{
                                        display: flex;
    flex-direction: column;
                                    }
                                </style>
                                <div class="item-icon-title pll">
                                    <div class="item-icon">
                                        <i class="flaticon-tutor"></i>
                                    </div>
                                    <div class="item-title">
                                        <h3 class="title">Top Instructors</h3>
                                    </div>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dumy text since the when took and scrambled to make type specimen book has survived.</p>
                            </div>
                            <!-- About Item End -->
                        </div>   
                        <div  data-aos="zoom-in" data-aos-delay="300"  class="col-lg-4">
                            <!-- About Item Start -->
                            <div style="box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;"class="about-item">
                                <style>
                                    .pll{
                                        display: flex;
    flex-direction: column;
                                    }
                                </style>
                                <div class="item-icon-title pll">
                                    <div class="item-icon">
                                        <i class="flaticon-tutor"></i>
                                    </div>
                                    <div class="item-title">
                                        <h3 class="title">Top Instructors</h3>
                                    </div>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dumy text since the when took and scrambled to make type specimen book has survived.</p>
                            </div>
                            <!-- About Item End -->
                        </div>  
                         <div  data-aos="zoom-in" data-aos-delay="400"  class="col-lg-4">
                            <!-- About Item Start -->
                            <div style="box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;"class="about-item">
                                <style>
                                    .pll{
                                        display: flex;
    flex-direction: column;
                                    }
                                </style>
                                <div class="item-icon-title pll">
                                    <div class="item-icon">
                                        <i class="flaticon-tutor"></i>
                                    </div>
                                    <div class="item-title">
                                        <h3 class="title">Top Instructors</h3>
                                    </div>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dumy text since the when took and scrambled to make type specimen book has survived.</p>
                            </div>
                            <!-- About Item End -->
                        </div>  
                         <div  data-aos="zoom-in" data-aos-delay="500"  class="col-lg-4">
                            <!-- About Item Start -->
                            <div style="box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;"class="about-item">
                                <style>
                                    .pll{
                                        display: flex;
    flex-direction: column;
                                    }
                                </style>
                                <div class="item-icon-title pll">
                                    <div class="item-icon">
                                        <i class="flaticon-tutor"></i>
                                    </div>
                                    <div class="item-title">
                                        <h3 class="title">Top Instructors</h3>
                                    </div>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dumy text since the when took and scrambled to make type specimen book has survived.</p>
                            </div>
                            <!-- About Item End -->
                        </div>
                           <div  data-aos="zoom-in" data-aos-delay="600"  class="col-lg-4">
                            <!-- About Item Start -->
                            <div style="box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;"class="about-item">
                                <style>
                                    .pll{
                                        display: flex;
    flex-direction: column;
                                    }
                                </style>
                                <div class="item-icon-title pll">
                                    <div class="item-icon">
                                        <i class="flaticon-tutor"></i>
                                    </div>
                                    <div class="item-title">
                                        <h3 class="title">Top Instructors</h3>
                                    </div>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dumy text since the when took and scrambled to make type specimen book has survived.</p>
                            </div>
                            <!-- About Item End -->
                        </div> 
                       
                       
                    </div>
                </div>
                <!-- About Items Wrapper End -->

            </div>
        </div>
        </div>
   
     


      <!-- Testimonial End -->
        <div class="section section-padding-02 mt-n1">
            <div class="container">

                <!-- Section Title Start -->
                <div class="section-title shape-03 text-center">
                    <h5 class="sub-title">Student Testimonial</h5>
                    <h2 class="main-title">Feedback From <span> Student</span></h2>
                </div>
                <!-- Section Title End -->

                <!-- Testimonial Wrapper End -->
                <div class="testimonial-wrapper testimonial-active">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <!-- Single Testimonial Start -->
                            <div class="single-testimonial swiper-slide">
                                <div class="testimonial-author">
                                    <div class="author-thumb">
                                        <img src="assets/images/author/author-06.jpg" alt="Author">

                                        <i class="icofont-quote-left"></i>
                                    </div>

                                    <span class="rating-star">
											<span class="rating-bar" style="width: 80%;"></span>
                                    </span>
                                </div>
                                <div class="testimonial-content">
                                    <p>Lorem Ipsum has been the industry's standard dummy text since the 1500s, when an unknown printer took a galley of type and scrambled it to make type specimen book has survived not five centuries but also the leap into electronic.</p>
                                    <h4 class="name">Sara Alexander</h4>
                                    <span class="designation">Product Designer, USA</span>
                                </div>
                            </div>
                            <!-- Single Testimonial End --> <!-- Single Testimonial Start -->
                            <div class="single-testimonial swiper-slide">
                                <div class="testimonial-author">
                                    <div class="author-thumb">
                                        <img src="assets/images/author/author-06.jpg" alt="Author">

                                        <i class="icofont-quote-left"></i>
                                    </div>

                                    <span class="rating-star">
											<span class="rating-bar" style="width: 80%;"></span>
                                    </span>
                                </div>
                                <div class="testimonial-content">
                                    <p>Lorem Ipsum has been the industry's standard dummy text since the 1500s, when an unknown printer took a galley of type and scrambled it to make type specimen book has survived not five centuries but also the leap into electronic.</p>
                                    <h4 class="name">Sara Alexander</h4>
                                    <span class="designation">Product Designer, USA</span>
                                </div>
                            </div>
                            <!-- Single Testimonial End --> <!-- Single Testimonial Start -->
                            <div class="single-testimonial swiper-slide">
                                <div class="testimonial-author">
                                    <div class="author-thumb">
                                        <img src="assets/images/author/author-06.jpg" alt="Author">

                                        <i class="icofont-quote-left"></i>
                                    </div>

                                    <span class="rating-star">
											<span class="rating-bar" style="width: 80%;"></span>
                                    </span>
                                </div>
                                <div class="testimonial-content">
                                    <p>Lorem Ipsum has been the industry's standard dummy text since the 1500s, when an unknown printer took a galley of type and scrambled it to make type specimen book has survived not five centuries but also the leap into electronic.</p>
                                    <h4 class="name">Sara Alexander</h4>
                                    <span class="designation">Product Designer, USA</span>
                                </div>
                            </div>
                            <!-- Single Testimonial End --> <!-- Single Testimonial Start -->
                            <div class="single-testimonial swiper-slide">
                                <div class="testimonial-author">
                                    <div class="author-thumb">
                                        <img src="assets/images/author/author-06.jpg" alt="Author">

                                        <i class="icofont-quote-left"></i>
                                    </div>

                                    <span class="rating-star">
											<span class="rating-bar" style="width: 80%;"></span>
                                    </span>
                                </div>
                                <div class="testimonial-content">
                                    <p>Lorem Ipsum has been the industry's standard dummy text since the 1500s, when an unknown printer took a galley of type and scrambled it to make type specimen book has survived not five centuries but also the leap into electronic.</p>
                                    <h4 class="name">Sara Alexander</h4>
                                    <span class="designation">Product Designer, USA</span>
                                </div>
                            </div>
                            <!-- Single Testimonial End -->

                        </div>

                        <!-- Add Pagination -->
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
                <!-- Testimonial Wrapper End -->

            </div>
        </div>
        <!-- Testimonial End -->
   
      <!-- Brand Logo Start -->
      <div class="section section-padding-02" style="padding-top: 25px;">
        <div class="container">

            <!-- Brand Logo Wrapper Start -->
            <div data-aos="zoom-in" class="brand-logo-wrapper"  style="box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;margin-bottom: 50px;">

                <img class="shape-1" src="assets/images/shape/shape-19.png" alt="Shape">

                <img class="shape-2 animation-round" src="assets/images/shape/shape-20.png" alt="Shape">

                <!-- Section Title Start -->
                <div class="section-title shape-03">
                    <h2 class="main-title">Best Supporter of <span> Our work.</span></h2>
                </div>
                <!-- Section Title End -->

                <!-- Brand Logo Start -->
                <div class="brand-logo brand-active">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">

                            <!-- Single Brand Start -->
                            <div class="single-brand swiper-slide">
                                <img src="assets/images/brand/brand-01.png" alt="Brand">
                            </div>
                            <!-- Single Brand End -->

                            <!-- Single Brand Start -->
                            <div class="single-brand swiper-slide">
                                <img src="assets/images/brand/brand-02.png" alt="Brand">
                            </div>
                            <!-- Single Brand End -->

                            <!-- Single Brand Start -->
                            <div class="single-brand swiper-slide">
                                <img src="assets/images/brand/brand-03.png" alt="Brand">
                            </div>
                            <!-- Single Brand End -->

                            <!-- Single Brand Start -->
                            <div class="single-brand swiper-slide">
                                <img src="assets/images/brand/brand-04.png" alt="Brand">
                            </div>
                            <!-- Single Brand End -->

                            <!-- Single Brand Start -->
                            <div class="single-brand swiper-slide">
                                <img src="assets/images/brand/brand-05.png" alt="Brand">
                            </div>
                            <!-- Single Brand End -->

                            <!-- Single Brand Start -->
                            <div class="single-brand swiper-slide">
                                <img src="assets/images/brand/brand-06.png" alt="Brand">
                            </div>
                            <!-- Single Brand End -->

                        </div>
                    </div>
                </div>
                <!-- Brand Logo End -->

            </div>
            <!-- Brand Logo Wrapper End -->

        </div>
    </div>
    <!-- Brand Logo End -->

 <?php include 'components/footer.php';?>

    </div>
            <!--Back To Start-->
            <a href="#" class="back-to-top">
            <i class="icofont-simple-up"></i>
        </a>
        <!--Back To End-->
<?php include 'components/js.php';?>

</body>


<!-- Mirrored from template.hasthemes.com/edule/eduLe/index.html by HTTrack Website Copier/3.x [XR&CO'2010], Wed, 16 Mar 2022 08:16:31 GMT -->
</html>