<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Assignment</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'components/css.php';?>
</head>

<body>

    <div class="main-wrapper">
<?php include 'components/header.php';?>
        <!-- Page Banner Start -->
        <style>
            .hl{
                margin-top: -40px;
            }
        </style>
        <div class="section page-banner hl">

            <img class="shape-1 animation-round" src="assets/images/shape/shape-8.png" alt="Shape">


            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">About</li>
                    </ul>
                    <h2 class="title">About  <span> Website</span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-badge"></i>
                    </div>
                </div>


            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->

      <!-- About Start -->
<div class="section mb-5">

                <div style="padding-top: 25px !important;" class="section-padding-02 mt-n10">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">

                                <!-- About Images Start -->
                                <div class="about-images">
                                    <div class="images">
                                        <img src="assets/images/about.jpg" alt="About">
                                    </div>

                                    <div class="about-years">
                                        <div class="years-icon">
                                            <img src="assets/images/logo-icon.png" alt="About">
                                        </div>
                                        <p><strong>28+</strong> Years Experience</p>
                                    </div>
                                </div>
                                <!-- About Images End -->

                            </div>
                            <div class="col-lg-6">

                                <!-- About Content Start -->
                                <div class="about-content">
                                    <h2 class="main-title">About<span> Website</span></h2>
                                    <p>Lorem Ipsum has been the industr’s standard dummy text ever since unknown printer took galley type and scmbled make type specimen book. It has survived not only five centuries.</p>
                                    <p>Lorem the industr’s standard dummy text ever since   the industr’s standard dummy text ever since   the industr’s standard dummy text ever since  Ipsum has been the industr’s standard dummy text ever since unknown printer took galley type and scmbled make type specimen book. It has survived not only five centuries.</p>
                                    <a href="#" class="btn btn-primary btn-hover-dark">Start A Course</a>
                                </div>
                                <!-- About Content End -->

                            </div>
                        </div>
                    </div>
                </div>



</div>
<!-- About End -->

 <?php include 'components/footer.php';?>

    </div>
            <!--Back To Start-->
            <a href="#" class="back-to-top">
            <i class="icofont-simple-up"></i>
        </a>
        <!--Back To End-->
<?php include 'components/js.php';?>

</body>


</html>