<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Assignment</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'components/css.php';?>
</head>

<body>

    <div class="main-wrapper">
<?php include 'components/header.php';?>
        <!-- Page Banner Start -->
        <style>
            .hl{
                margin-top: -40px;
            }
        </style>
        <div class="section page-banner hl">

            <img class="shape-1 animation-round" src="assets/images/shape/shape-8.png" alt="Shape">


            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">Login</li>
                    </ul>
                    <h2 class="title">Login <span> Form</span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-badge"></i>
                    </div>
                </div>


            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->

     <!-- Blog Start -->
     <div class="section section-padding mt-n10">
            <div class="container">

                <!-- Blog Wrapper Start -->
                <div class="blog-wrapper">
                    <div class="row">
                        <div class="col-lg-4 col-md-6">

                            <!-- Single Blog Start -->
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog-detail.php"><img src="assets/images/blog/blog-01.jpg" alt="Blog"></a>
                                </div>
                                <div class="blog-content">
                                  

                                    <h4 class="title"><a href="blog-detail.php">Data Science and Machine Learning with Python - Hands On!</a></h4>

                                    <div class="blog-meta">
                                        <span> <i class="icofont-calendar"></i> 21 March, 2021</span>
                                        <span> <i class="icofont-heart"></i> 2,568+ </span>
                                    </div>

                                    <a href="blog-detail.php" class="btn btn-secondary btn-hover-primary">Read More</a>
                                </div>
                            </div>
                            <!-- Single Blog End -->

                        </div> <div class="col-lg-4 col-md-6">

                            <!-- Single Blog Start -->
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog-detail.php"><img src="assets/images/blog/blog-01.jpg" alt="Blog"></a>
                                </div>
                                <div class="blog-content">
                                  

                                    <h4 class="title"><a href="blog-detail.php">Data Science and Machine Learning with Python - Hands On!</a></h4>

                                    <div class="blog-meta">
                                        <span> <i class="icofont-calendar"></i> 21 March, 2021</span>
                                        <span> <i class="icofont-heart"></i> 2,568+ </span>
                                    </div>

                                    <a href="blog-detail.php" class="btn btn-secondary btn-hover-primary">Read More</a>
                                </div>
                            </div>
                            <!-- Single Blog End -->

                        </div> <div class="col-lg-4 col-md-6">

                            <!-- Single Blog Start -->
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog-detail.php"><img src="assets/images/blog/blog-01.jpg" alt="Blog"></a>
                                </div>
                                <div class="blog-content">
                                  

                                    <h4 class="title"><a href="blog-detail.php">Data Science and Machine Learning with Python - Hands On!</a></h4>

                                    <div class="blog-meta">
                                        <span> <i class="icofont-calendar"></i> 21 March, 2021</span>
                                        <span> <i class="icofont-heart"></i> 2,568+ </span>
                                    </div>

                                    <a href="blog-detail.php" class="btn btn-secondary btn-hover-primary">Read More</a>
                                </div>
                            </div>
                            <!-- Single Blog End -->

                        </div> <div class="col-lg-4 col-md-6">

                            <!-- Single Blog Start -->
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog-detail.php"><img src="assets/images/blog/blog-01.jpg" alt="Blog"></a>
                                </div>
                                <div class="blog-content">
                                  

                                    <h4 class="title"><a href="blog-detail.php">Data Science and Machine Learning with Python - Hands On!</a></h4>

                                    <div class="blog-meta">
                                        <span> <i class="icofont-calendar"></i> 21 March, 2021</span>
                                        <span> <i class="icofont-heart"></i> 2,568+ </span>
                                    </div>

                                    <a href="blog-detail.php" class="btn btn-secondary btn-hover-primary">Read More</a>
                                </div>
                            </div>
                            <!-- Single Blog End -->

                        </div> <div class="col-lg-4 col-md-6">

                            <!-- Single Blog Start -->
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog-detail.php"><img src="assets/images/blog/blog-01.jpg" alt="Blog"></a>
                                </div>
                                <div class="blog-content">
                                  

                                    <h4 class="title"><a href="blog-detail.php">Data Science and Machine Learning with Python - Hands On!</a></h4>

                                    <div class="blog-meta">
                                        <span> <i class="icofont-calendar"></i> 21 March, 2021</span>
                                        <span> <i class="icofont-heart"></i> 2,568+ </span>
                                    </div>

                                    <a href="blog-detail.php" class="btn btn-secondary btn-hover-primary">Read More</a>
                                </div>
                            </div>
                            <!-- Single Blog End -->

                        </div> <div class="col-lg-4 col-md-6">

                            <!-- Single Blog Start -->
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog-detail.php"><img src="assets/images/blog/blog-01.jpg" alt="Blog"></a>
                                </div>
                                <div class="blog-content">
                                  

                                    <h4 class="title"><a href="blog-detail.php">Data Science and Machine Learning with Python - Hands On!</a></h4>

                                    <div class="blog-meta">
                                        <span> <i class="icofont-calendar"></i> 21 March, 2021</span>
                                        <span> <i class="icofont-heart"></i> 2,568+ </span>
                                    </div>

                                    <a href="blog-detail.php" class="btn btn-secondary btn-hover-primary">Read More</a>
                                </div>
                            </div>
                            <!-- Single Blog End -->

                        </div>
                      
                    </div>
                </div>
                <!-- Blog Wrapper End -->

                <!-- Page Pagination End -->
                <div class="page-pagination">
                    <ul class="pagination justify-content-center">
                        <li><a href="#"><i class="icofont-rounded-left"></i></a></li>
                        <li><a class="active" href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#"><i class="icofont-rounded-right"></i></a></li>
                    </ul>
                </div>
                <!-- Page Pagination End -->

            </div>
        </div>
        <!-- Blog End -->




 <?php include 'components/footer.php';?>

    </div>
            <!--Back To Start-->
            <a href="#" class="back-to-top">
            <i class="icofont-simple-up"></i>
        </a>
        <!--Back To End-->
<?php include 'components/js.php';?>

</body>


</html>