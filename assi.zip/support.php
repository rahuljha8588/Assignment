<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Assignment</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'components/css.php'; ?>
</head>

<body>

    <div class="main-wrapper">
<?php include 'components/header.php'; ?>
        <!-- Page Banner Start -->
        <style>
            .hl{
                margin-top: -40px;
            }
        </style>
        <div class="section page-banner hl">

            <img class="shape-1 animation-round" src="assets/images/shape/shape-8.png" alt="Shape">


            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">support</li>
                    </ul>
                    <h2 class="title">Support <span></span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-badge"></i>
                    </div>
                </div>


            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->

        <section style="margin-top: 30px;" class="faq-section ptb-120">
                                            <div class="container">
                                                <div class="row justify-content-center">
                                                    <div class="col-lg-6 col-md-12" style="padding-bottom:37px">
                                                        <div class="section-heading text-center aos-init aos-animate" data-aos="fade-up">
                                                            <h4 class="h5 text-primary">FAQ</h4>
                                                            <h2>Frequently Asked Questions</h2>
                                                            <p>Efficiently network cross-unit paradigms for premier technologies scale 24/7 paradigms for process-centric data interoperable.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row justify-content-center">
                                                <div class="col-lg-12 col-md-12">
                                                    
                                                    
                                                    <div class="col-lg-12 col-md-12" style="box-shadow: 0 1rem 3rem rgb(0 0 0 / 18%) !important;  padding: 17px;  border-radius: 16px;">
                                                        <div class="faq-content-wrap d-flex mb-5 aos-init aos-animate" data-aos="fade-up" data-aos-delay="50">
                                                            <span class="faq-icon me-3"><i class="fal fa-copyright text-primary"></i></span>
                                                            <div class="faq-info">
                                                                <h5>QUESTIONS ABOUT MEMBERSHIP</h5>
                                                                                                <p style="font-size: 17px;  color: #071c4d;"> How do I join the panel?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>It's very easy. Simply fill in your details on our sign-up page. We'll send you a link to the application form so you are able to set up your Account and become a panel member. If you are 16 or younger, ask your parent or guardian to apply on your behalf, and you can take part in the surveys via them.</p>
                                <p></p>
                                                                
                                                                <br>
                                                                                                <p style="font-size: 17px;  color: #071c4d;"> Can I join the panel if I live outside the USA?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>Yes, this is a global panel, and you can participate from anywhere in the world.</p><p></p>
                                                                
                                                                <br>
                                                                                                <p style="font-size: 17px;  color: #071c4d;"> Will it cost me anything to join Global Critique Panel?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>There are no costs associated with joining the panel and you can leave at any time. However, you'll need an e-mail address to receive invitations to participate in surveys and you'll need to be able to access the internet to complete our online surveys.</p>
                                <p></p>
                                                                
                                                                <br>
                                                                                                <p style="font-size: 17px;  color: #071c4d;"> What happens after I join?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>We will send you an e-mail welcoming you to Global Critique Panel and you will begin receiving e-mail invitations to take surveys. The e-mails will contain all the information you need to take part. Once you complete a survey, you'll have the opportunity to earn points.</p>
                                <p></p>
                                                                
                                                                <br>
                                                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    </div>
                                                    
                                                    
                                                    <div class="col-lg-12 col-md-12" style="    margin-top: 32px;">
                                                    <div class="col-lg-12 col-md-12" style="box-shadow: 0 1rem 3rem rgb(0 0 0 / 18%) !important;  padding: 17px;  border-radius: 16px;">
                                                        <div class="faq-content-wrap d-flex mb-5 aos-init aos-animate" data-aos="fade-up" data-aos-delay="50">
                                                            <span class="faq-icon me-3"><i class="fal fa-copyright text-primary"></i></span>
                                                            <div class="faq-info">
                                                                <h5>QUESTIONS ABOUT PRICING</h5>
                                                                                                <p style="font-size: 17px;  color: #071c4d;"> Why are surveys conducted?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>Surveys are conducted because businesses, governments, public bodies, and similar organisations are interested in the views and attitudes of the people who use their products and services. The more they know about what customers and citizens think, the easier it is for them to improve and adapt what they supply.</p>
                                <p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> How often will I be asked to take surveys?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>We send out survey invitations on a regular basis, but cannot say who or when you might receive invitations. This is because each survey is customised and based around the research goals for each individual client. Depending on your profile, we may ask you to complete surveys more or less often. For this reason, we ask you to keep your profile as up to date as possible. Please note some firewalls may prevent delivery of our survey invitations.</p>
                                <p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> Can you mail the surveys to me or conduct them over the phone?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>Unfortunately there is no other way to take part in these online surveys, you need to complete them over the Internet.</p>
                                <p></p>
                                                                <br>
                                                                                            
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    </div>


                                <div class="col-lg-12 col-md-12" style="    margin-top: 32px;">
                                                    <div class="col-lg-12 col-md-12" style="box-shadow: 0 1rem 3rem rgb(0 0 0 / 18%) !important;  padding: 17px;  border-radius: 16px;">
                                                        <div class="faq-content-wrap d-flex mb-5 aos-init aos-animate" data-aos="fade-up" data-aos-delay="50">
                                                            <span class="faq-icon me-3"><i class="fal fa-copyright text-primary"></i></span>
                                                            <div class="faq-info">
                                                                <h5>QUESTIONS ABOUT PRIVACY</h5>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> If I join Global Critique Panel, will I receive e-mails advertising other products and services?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>No. We don't sell the personal information of our panellists and we'll never try to sell you a product or service.</p>
                                                                    <p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> Who can I talk to if I have any privacy concerns?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>Contact information is provided in our Privacy Policy, which is linked from the bottom of the pages on the Global Critique Panel website.</p>
                                <                                   p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> Why do you need my personal information?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>Generally, personal information is used: (i) to communicate with you regarding your Account and survey participation; (ii) to tailor survey opportunities to you; (iii) to comply with legal obligations, including, without limitation, complying with taxation requirements; (iv) to administer and manage our incentive programmes and fulfill your requests for incentives; (v) to facilitate your entry into our prize draw and communicate with you regarding prize draw entries; and (vi) to update our records.</p>
                                                                    <p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> Why did I get an e-mail with a link to join Global Critique Panel if I didn't apply myself?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>It is possible that someone made a typing error and accidentally submitted your e-mail address while asking to join Global Critique Panel. It's also possible that someone has used your e-mail address without your permission. If you don't want to join, simply ignore the e-mail and the reminder that will be sent. Your details won't be included on our records and you'll not be contacted again.</p>
                                                                    <p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> How do I unsubscribe from the Global Critique Panel?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> We appreciate your participation in the panel and encourage you to remain part of our community. However, if you would like to unsubscribe from the Global Critique panel at any time, you may do so by sending an email to us at panelsupport@globalcritiquepanel.com &amp; Click on Contact us on our panel site select the subject Account Closure Request or Unsubscribe.We shall use reasonable efforts, as required by law or regulation, to respond to each email request within a reasonable period of time after receipt. Upon termination of Services, a Panel Member’s contact information will be removed from all communication or contact lists relating to the terminated Service(s). Please note that it may take a 7 days to complete the removal and during such time, You may receive messages from Us which were created or compiled prior to your opt-out.</p>
                                                                <br>
                                                                                            
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    </div>





                                                    <div class="col-lg-12 col-md-12" style="    margin-top: 32px;">
                                                    <div class="col-lg-12 col-md-12" style="box-shadow: 0 1rem 3rem rgb(0 0 0 / 18%) !important;  padding: 17px;  border-radius: 16px;">
                                                        <div class="faq-content-wrap d-flex mb-5 aos-init aos-animate" data-aos="fade-up" data-aos-delay="50">
                                                            <span class="faq-icon me-3"><i class="fal fa-copyright text-primary"></i></span>
                                                            <div class="faq-info">
                                                                <h5>QUESTIONS ABOUT SERVICES</h5>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> How do achievements work?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>As you continue completing activities with Global Critique Panel, you’ll level up.<br>There are 3 level<br>At each level, there are key milestones required to complete your level.</p><p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> How do I level up?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>Your level is related to your membership, based on your actions like taking surveys and earning rewards.<br>You can level up by unlocking all the achievements available at your current level in a 365 day period. For example, if you’re a Frist Level member, you need to complete all the available First Level activities to level up and become a Second Level member.<br>You can also unlock achievements for levels above your current one. For example, if you complete 100% of your survey profile, you’ll get a Third Level status badge – but you cannot reach Third  level until you’ve achieved all the necessary achievements.</p><p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> What is a First Level?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>First Level members are just getting started. To reach First Level status, all you have to do is sign up and activate your account.</p><p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> What is a Third Level member?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>Third Level members have reached the top. They have a complete profile, completed fifty activities (or more) and maintain regular activity.<br><br>To reach Third Leve  status, members must:<br>&nbsp;</p><ul>	<li>Complete 100% of their survey profile</li>	<li>Take a survey in three consecutive weeks</li>	<li>Complete 50 activities</li></ul><p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> What is a Second Level member?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p> Second Level members are active and regular members who have almost completed their profile.<br><br>To reach  Second Level status, members must:<br>&nbsp;</p><ul>	<li>Complete 75% of their survey profile</li>	<li>Take a survey in three consecutive weeks</li>	<li>Complete 25 activities</li></ul><p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> How do I maintain my level?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>It’s simple - keep sharing your opinions. We recommend taking activities at least once a week to maintain your current level.<br>
                                                                If you don’t keep it up, you will eventually lose your achievement for consecutive activities and drop down a level.<br>
                                                                Similarly, you’ll need to make sure your profile is kept up to date. Certain sections, like technology and automotive, will expire over time – so if your profile completion percentage has dropped since you last logged in, check back and complete any sections that are incomplete.</p>
                                                                <p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> Where can I see the rewards I have earned from achievements?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>The points earned from achievements can be found in your survey history page. This will show as 'community achievement'.</p>
                                                                <p></p>
                                                                <br>
                                                                                            <p style="font-size: 17px;  color: #071c4d;"> How can I view my achievements?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>To see all the achievements you've earned, head to the ‘Achievements' tab.</p>
                                                                    <p></p>
                                                                <br>
                                                                                            
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    </div>


                                <div class="col-lg-12 col-md-12" style="    margin-top: 32px;">
                                                    <div class="col-lg-12 col-md-12" style=" margin-bottom:30px;box-shadow: 0 1rem 3rem rgb(0 0 0 / 18%) !important;  padding: 17px;  border-radius: 16px;">
                                                        <div class="faq-content-wrap d-flex mb-5 aos-init aos-animate" data-aos="fade-up" data-aos-delay="50">
                                                            <span class="faq-icon me-3"><i class="fal fa-copyright text-primary"></i></span>
                                                            <div class="faq-info">
                                                                <h5>QUESTIONS ABOUT ASSIGNMENT</h5>
                                                                
                                                                
                                                                
                                                                                                <p style="font-size: 17px;  color: #071c4d;"> Does it cost me anything?</p>
                                                                <p class="mb-0" style="line-height: 18px; font-size: 14px;"> </p><p>No. This donation is separate to your survey rewards and does not affect your points balance.<br>This does not constitute a donation on your behalf so is not tax deductible.</p><p></p>
                                                                <br>
                                                                                            
                                                                
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    </div>

                                                </div>
                                            </div>
                                        
        </section>

 <?php include 'components/footer.php'; ?>

    </div>
            <!--Back To Start-->
            <a href="#" class="back-to-top">
            <i class="icofont-simple-up"></i>
        </a>
        <!--Back To End-->
<?php include 'components/js.php'; ?>

</body>


</html>