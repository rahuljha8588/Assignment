       <!-- Footer Start  -->
       <div class="section footer-section">

<!-- Footer Widget Section Start -->
<div class="footer-widget-section">

    <img class="shape-1 animation-down" src="assets/images/shape/shape-21.png" alt="Shape">

    <div class="container">
        <div class="row">                                              
          
            
            <div class="col-lg-3">
                <div class="footer-widget">
                    <div class="widget-logo">
                        <a href="#"><img src="assets/images/logo.png" alt="Logo"></a>
                    </div>

                

                   
                      <p style="padding: 10px;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti quos quam mollitia et perspiciatis officia eveniet magnam qui saeniti quos quam mollitia eteveniet magnam qui sapiente! Id sint</p>
                   

                </div>
            </div>
             <div class="col-lg-3">
                <div class="footer-widget">
                    <h4 class="footer-widget-title">Services </h4>

                    <ul class="widget-link">
                        <li><a href="service.php">Assignment Service</a></li>
                        <li><a href="service.php">Assignment Service</a></li>
                        <li><a href="service.php">Assignment Service</a></li>
                        <li><a href="service.php">Assignment Service</a></li>
                        <li><a href="service.php">Assignment Service</a></li>
                       
                    </ul>

                </div>
            </div>  
            <div class="col-lg-3">
                <div class="footer-widget">
                    <h4 class="footer-widget-title">Quick Links</h4>

                    <ul class="widget-link">
                        <li><a href="blog.php">Blog</a></li>
                        <li><a href="support.php">Support</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="terms.php">Terms & Conditions</a></li>
                        <li><a href="privacy.php">Privacy Policy</a></li>
                    </ul>

                </div>
            </div>
            <div class="col-lg-3">
                <div class="footer-widget">
                  

                    <div class="widget-address">
                        <h4 class="footer-widget-title">Caribbean Ct</h4>
                        <p>Haymarket, Virginia (VA).</p>
                    </div>

                    <ul class="widget-info">
                        <li>
                            <p> <i class="flaticon-email"></i> <a href="mailto:address@gmail.com">address@gmail.com</a> </p>
                        </li>
                        <li>
                            <p> <i class="flaticon-phone-call"></i> <a href="tel:9702621413">(970) 262-1413</a> </p>
                        </li>
                    </ul>

                    <ul class="widget-social">
                        <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                        <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                        <li><a href="#"><i class="flaticon-skype"></i></a></li>
                        <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
          
        </div>
    </div>

    <img class="shape-2 animation-left" src="assets/images/shape/shape-22.png" alt="Shape">

</div>
<!-- Footer Widget Section End -->

<!-- Footer Copyright Start -->
<div class="footer-copyright">
    <div class="container">

        <!-- Footer Copyright Start -->
        <div class="copyright-wrapper" style="display: flex;justify-content: center;padding-bottom: 2px;">
            
            <div class="copyright-text py-2">
                <p>&copy; 2021 Made with <i class="icofont-heart-alt"></i> by <a href="#">MRC Infotech</a></p>
            </div>
        </div>
        <!-- Footer Copyright End -->

    </div>
</div>
<!-- Footer Copyright End -->

</div>
<!-- Footer End -->