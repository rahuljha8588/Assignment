
        <!-- Header Section Start -->
        <div class="header-section">

            <!-- Header Top Start -->
            <div class="header-top d-none d-lg-block">
                <div class="container">

                    <!-- Header Top Wrapper Start -->
                    <div class="header-top-wrapper">

                        <!-- Header Top Left Start -->
                        <div class="header-top-left">
                            <p>All course 28% off for <a href="#">Liberian people’s.</a></p>
                        </div>
                        <!-- Header Top Left End -->

                        <!-- Header Top Medal Start -->
                        <div class="header-top-medal">
                            <div class="top-info">
                                <p><i class="flaticon-phone-call"></i> <a href="tel:9702621413">(970) 262-1413</a></p>
                                <p><i class="flaticon-email"></i> <a href="mailto:address@gmail.com">address@gmail.com</a></p>
                            </div>
                        </div>
                        <!-- Header Top Medal End -->

                        <!-- Header Top Right Start -->
                        <div class="header-top-right">
                            <ul class="social">
                                <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                                <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                                <li><a href="#"><i class="flaticon-skype"></i></a></li>
                                <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                            </ul>
                        </div>
                        <!-- Header Top Right End -->

                    </div>
                    <!-- Header Top Wrapper End -->

                </div>
            </div>
            <!-- Header Top End -->

            <!-- Header Main Start -->
            <div class="header-main">
                <div class="container-fluid">

                    <!-- Header Main Start -->
                    <div class="header-main-wrapper" style="border-radius:0px;margin-top: 0px;">

                        <!-- Header Logo Start -->
                        <div class="header-logo">
                            <a href="index.php"><img src="assets/images/logo.png" alt="Logo"></a>
                        </div>
                        <!-- Header Logo End -->
                    <style>
                        .inc{
                            width: 400px !important;
                        }
                    </style>
                        <!-- Header Menu Start -->
                        <div class="header-menu d-none d-lg-block">
                            <ul class="nav-menu">
                                <li><a href="index.php">Search</a></li>
                                <li>
                                    <a href="#">Services</a>
                                    <ul class="sub-menu  inc">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-4">
                                                  <li><a href="service.php">Service</a></li>
                                                  <li><a href="service.php">Service</a></li>
                                                  <li><a href="service.php">Service</a></li>
                                                  <li><a href="service.php">Service</a></li>
                                                  <li><a href="service.php">Service</a></li>
                                                  <li><a href="service.php">Service</a></li>
                                              </div>
                                              <div class="col-md-4">
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                            </div>
                                            <div class="col-md-4">
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                                <li><a href="service.php">Service</a></li>
                                            </div>
                                              
                                          </div>
                                      </div>
                                    </ul>
                                </li>
                              
                                <li>
                                    <a href="blog.php">Blog</a>
                                   
                                </li>
                                <li>
                                    <a href="support.php">Support </a>
                                  
                                </li>
                                
                                 <li>
                                    <a href="#">Account </a>
                                    <ul class="sub-menu">
                                        <li><a href="login.php">Login</a></li>
                                        <li><a href="signup.php">Sign Up</a></li>
                                    
                                    </ul>
                                </li>
                            </ul>

                        </div>
                        <!-- Header Menu End -->


                        <!-- Header Mobile Toggle Start -->
                        <div class="header-toggle d-lg-none">
                            <a class="menu-toggle" href="javascript:void(0)">
                                <span></span>
                                <span></span>
                                <span></span>
                            </a>
                        </div>
                        <!-- Header Mobile Toggle End -->

                    </div>
                    <!-- Header Main End -->

                </div>
            </div>
            <!-- Header Main End -->

        </div>
        <!-- Header Section End -->

        <!-- Mobile Menu Start -->
        <div class="mobile-menu">

            <!-- Menu Close Start -->
            <a class="menu-close" href="javascript:void(0)">
                <i class="icofont-close-line"></i>
            </a>
            <!-- Menu Close End -->

            <!-- Mobile Top Medal Start -->
            <div class="mobile-top">
                <p><i class="flaticon-phone-call"></i> <a href="tel:9702621413">(970) 262-1413</a></p>
                <p><i class="flaticon-email"></i> <a href="mailto:address@gmail.com">address@gmail.com</a></p>
            </div>
            <!-- Mobile Top Medal End -->

            <!-- Mobile Sing In & Up Start -->
            <div class="mobile-sign-in-up">
                <ul>
                    <li><a class="sign-in" href="login.php">Sign In</a></li>
                    <li><a class="sign-up" href="signup.php">Sign Up</a></li>
                </ul>
            </div>
            <!-- Mobile Sing In & Up End -->

            <!-- Mobile Menu Start -->
            <div class="mobile-menu-items">
                <ul class="nav-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li>
                        <a href="#">Services </a>
                        <ul class="sub-menu">
                            <li><a href="service.php">Service</a></li>
                            <li><a href="service.php">Service</a></li>
                            <li><a href="service.php">Service</a></li>
                            <li><a href="service.php">Service</a></li>
                        </ul>
                    </li>
                    <li><a href="support.php">Support</a></li>
                    
                   
                    <li>
                        <a href="blog.php">Blog</a>
                      
                    </li>
                </ul>

            </div>
            <!-- Mobile Menu End -->

            <!-- Mobile Menu End -->
            <div class="mobile-social">
                <ul class="social">
                    <li><a href="#"><i class="flaticon-facebook"></i></a></li>
                    <li><a href="#"><i class="flaticon-twitter"></i></a></li>
                    <li><a href="#"><i class="flaticon-skype"></i></a></li>
                    <li><a href="#"><i class="flaticon-instagram"></i></a></li>
                </ul>
            </div>
            <!-- Mobile Menu End -->

        </div>
        <!-- Mobile Menu End -->

                <!-- Overlay Start -->
                <div class="overlay"></div>
        <!-- Overlay End -->