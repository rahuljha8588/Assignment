<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Assignment</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'components/css.php';?>
</head>

<body>

    <div class="main-wrapper">
<?php include 'components/header.php';?>
        <!-- Page Banner Start -->
        <style>
            .hl{
                margin-top: -40px;
            }
        </style>
        <div class="section page-banner hl">

            <img class="shape-1 animation-round" src="assets/images/shape/shape-8.png" alt="Shape">


            <div class="container">
                <!-- Page Banner Start -->
                <div class="page-banner-content">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">terms & conditions</li>
                    </ul>
                    <h2 class="title">Terms &<span> Conditions</span></h2>
                </div>
                <!-- Page Banner End -->
            </div>

            <!-- Shape Icon Box Start -->
            <div class="shape-icon-box">

                <img class="icon-shape-1 animation-left" src="assets/images/shape/shape-5.png" alt="Shape">

                <div class="box-content">
                    <div class="box-wrapper">
                        <i class="flaticon-badge"></i>
                    </div>
                </div>


            </div>
            <!-- Shape Icon Box End -->

            <img class="shape-3" src="assets/images/shape/shape-24.png" alt="Shape">

            <img class="shape-author" src="assets/images/author/author-11.jpg" alt="Shape">

        </div>
        <!-- Page Banner End -->


        <div class="site-content" style="padding-top:150px;">
    <div class="container">
<p><span>l (the “”) is a market research access  owned and operated by   Service Pvt Ltd and its parent, subsidiary and affiliated companies, including   Service Pvt Ltd (collectively "  Service").</span></p>

<p><span>As a member of the , you will have the opportunity to participate in market research activities including online and mobile surveys, product tests, focus groups, and more.</span></p>

<p><span>These terms are subject to change. For more information on how we use the data you provide, please see our https://.com/privacy.php.</span></p>

<p><span>These General Terms &amp; Conditions/Terms of Use include a class action waiver and a waiver of jury trials and require binding arbitration on an individual basis to resolve disputes.</span></p>

<p><span>1. Applicability; Agreement</span></p>

<p><span>These General Terms and Conditions/Terms of Use (these “Terms”) govern and apply to all of   Service’s applications and services, including, but not limited to, (1) any   Service  or sub (individually a “” and collectively the “s”), (2) any  website (individually a “Website” and collectively the “Websites”), (3) any   Service mobile application(s), (4) participation in any survey or study offered, provided, hosted or administered by or through   Service and (5) your eligibility for, and/or redemption of, rewards, incentives and prizes offered for certain actions and activities, including, but not limited to, successfully completing surveys (collectively, the “Applications/Services”).</span></p>

<p><span>All references in these terms to “  Service” include   Service, and its parents, subsidiaries and affiliates, including l and   Service. All references in these Terms to “us” or “we” refer to   Service.</span></p>

<p><span>By registering for, accessing, using, and/or participating in, the Applications/Services, you hereby expressly agree to comply with and be bound by these Terms.</span></p>

<p><span>  Service reserves the right to refuse, restrict, prohibit or reject your access to, use of, and/or participation in the Applications/Services, at any time and for any reason.</span></p>

<p><span>2. Membership Eligibility and Participation</span></p>

<p><span>The Applications/Services are strictly for your personal, non-commercial use. You may use the Applications/Services only when and as available. The Applications/Services are only available to individuals who are seventeen (17) years of age or older residing in the World Wide. Participation on the  is limited to only one (1) account per person. From time to time our clients may want to survey the opinion of minors, they may only participate with parental consent, via their parent’s account.</span></p>

<p><span>  Service employees are not permitted to participate in the  for personal use (see Section 19).</span></p>

<p><span>Your participation in survey, focus group, telephone or other research (“Research”) through the Applications/Services is based on your desire to share opinions and provide feedback. Such participation in the Research is voluntary for you, without control or direction of   Service, and you shall exercise independent judgment and discretion while doing so.</span></p>

<p><span>3. Use of the Applications/Services</span></p>

<p><span>The Applications/Services are for personal, non-commercial use. You may use the Applications/Services only when and as available.   Service reserves the right to change, modify or eliminate, and/or restrict or block access to, all or any part of the Applications/Services, without notice, at any time, for any reason or for no reason.</span></p>

<p><span>  Service provides  members and non- members with the opportunity to participate in surveys. Participation in surveys is voluntary. By agreeing to become a  member, you agree to receive invitations to participate in surveys. Additionally, l &nbsp;may provide  members with the opportunity to communicate with other  members and/or   Panle. You may unsubscribe from  membership at any time; see Section 10 "Opt Out Policy" below.</span></p>

<p><span>If you are registering for the Application/Services, you will be required to provide or disclose certain personally identifiable information (“PII”) to   Service. Please review l Privacy Policy for information on l &nbsp;privacy practices.</span></p>

<p><span>4.  Registration; Passwords</span></p>

<p><span>You may access any Website(s) as a visitor without registering for membership with the  associated with the Website(s) and without providing or disclosing personal information.</span></p>

<p><span>In order to register as a  member, you must register with or for the  and provide certain personal information.  members and non- members are required to truthfully provide all information.   Service reserves the right to restrict or prohibit your use of, access to and/or participation in the Applications/Services if you provide, or   Service reasonably suspects that you have provided, information that is untrue, inaccurate, not current, or incomplete.</span></p>

<p><span>Each  member will create his/her own username and password.  members are solely responsible for the security of their usernames and passwords and will be solely liable and responsible for any use, whether authorized or unauthorized, of their membership accounts.   Service spanly recommends against the use of a social security number, financial account number or any other identification or account number, as a username or password. Please do not disclose your password to anyone else, you are responsible for keeping it safe. We will not be liable for any unauthorized use of your account, which includes unauthorized use of your email address, password and reward redemption.</span></p>

<p><span> membership is specific to the individual who registers for membership with the ;  membership is not transferrable.</span></p>

<p><span>You acknowledge that you are accessing, using and/or participating in the Applications/Services in the capacity of an independent contractor and that no agency, partnership, join venture, employee–employer or franchisor–franchisee relationship is intended or created by this agreement.</span></p>

<p><span>5. Unauthorized Uses</span></p>

<p><span>You agree not to: (i) use spiders, robots or other automated data mining techniques to catalogue, download, store or otherwise reproduce or distribute data or content available in connection with the Applications/Services, or to manipulate the results of any survey, prize draw or contest; (ii) take any action to interfere with any Website(s) or an individual’s use of any Website, including, but not limited to, by overloading, “flooding”, “mail bombing” or “crashing” any Website; (iii) send or transmit any viruses, corrupted data or any other harmful, disruptive or destructive code, file or information, including, but not limited to, spyware; (iv) collect any personally identifiable information of or about any other user of the Applications/Services; (v) send unsolicited emails, including, but not limited to, promotions and/or advertising of products or services; (vi) open, use, or maintain more than one (1) membership account with a ; (vii) Forge or mask your true identity; (viii) frame a portion(s) of any Website within another website or alter the appearance of any Website; (ix) establish links from any other website to any page of, on or located within any Website or to the Applications/Services, without the prior express written permission of   Service; (x) post or transmit any threatening, libellous, defamatory, obscene, pornographic, lewd, scandalous or inflammatory material or content or any material or content that could otherwise violate Applicable Laws (as defined herein); (xi) engage in any fraudulent activity, including, but not limited to, speeding through surveys, taking the same survey more than once, masking or forging your identity, submitting false information during the registration process, submitting false or untrue survey data, redeeming or attempting to redeem rewards, prizes and/or incentives through false or fraudulent means, and tampering with surveys; (xii) reverse engineer any aspect of the Applications/Services or do any act or take any action that might reveal or disclose the source code, or bypass or circumvent measurers or controls utilized to prohibit, restrict or limit access to any webpage, content or code, except as expressly permitted by Applicable Laws; (xiii) engage in any criminal or illegal act(s); (xiv) use Restricted Content (as defined herein) in violation or breach of these Terms; or (xv) encourage and/or advise any individual, including, but not limited to, any   Service employee, to commit any act(s) prohibited hereunder.</span></p>

<p><span>You acknowledge and agree that   Service will fully cooperate with all legal disclosure request(s) (e.g. court order or subpoena).</span></p>

<p><span>6. Restricted Content</span></p>

<p><span>In connection with your use of, access to and/or participation in the Applications/Services, you may have the opportunity to review or access confidential and proprietary information, materials, products and content (“Restricted Content”) belonging to   Service and/or   Service’s clients, partners and/or licensors. Restricted Content is and shall remain the sole and exclusive property of the owner of the Restricted Content. In no event shall you obtain or receive any right, title and/or interest in or to any Restricted Content. You agree to protect the confidentiality and secrecy of the Restricted Content and you agree not to modify, copy, reproduce, republish, display, transmit, distribute, reverse engineer, create derivative works of, decompile or otherwise use, alter or transfer Restricted Content without the prior express written consent of   Service. You acknowledge and agree that Restricted Content may be subject to, and protected by, intellectual property laws, regulations and codes. You further acknowledge and agree that if you breach or otherwise violate the restrictions, limitations and prohibitions contained in this Section, in addition to any other rights or remedies available to   Service,   Service reserves the right to terminate, prohibit or restrict your use of, access to and/or participation in the Applications/Services.</span></p>

<p><span>7. User Content</span></p>

<p><span>You are solely liable and responsible for all content, materials, information and comments you use, upload, post or submit in connection with the Applications/Services (“User Content”). You are solely responsible for all third party approvals, consents and/or authorizations required for User Content. If you submit User Content, the User Content may become publicly available and may be shared with third parties including, but not limited to,   Service’s clients, clients of   Service’s clients, and third party service providers. User Content should only include audio, video, images or the likeness of the individual submitting the User Content and should not contain copyrighted or trademarked content or material of any third party. User Content should not include audio, video, images, or the likeness of anyone other than the user. You will not receive compensation for any User Content. If you would like information about the identity of the sponsor of a survey in which you submit photos or videos, please contact   Service as set forth in   Service’s Privacy Policy. In order to identify the specific survey, you will need to provide   Service with your email address and information on the specific survey (e.g., survey number, survey topic or subject matter, date you completed the survey, etc.).</span></p>

<p><span>By using, uploading, posting or submitting User Content in connection with the Applications/Services, you hereby grant to   Service a perpetual, irrevocable, unlimited, transferrable, sub-licensable, world-wide, royalty free, right and license to edit, copy, transmit, publish, display, create derivative works of, reproduce, modify, distribute and otherwise use, modify or distribute your User Content in any manner, without compensation or notice.</span></p>

<p><span>You are solely responsible for User Content.   Service does not and cannot review all User Content and   Service is not responsible for User Content.   Service reserves the right to delete, move or edit User Content that is, in   Service’s sole discretion, deemed to: (i) violate these Terms, (ii) violate copyright or trademark laws, or (iii) be abusive, defamatory, obscene or otherwise unacceptable.</span></p>

<p><span>8. Rewards Programs</span></p>

<p><span>A. In connection with your use of the Applications/Services, you may have the opportunity to accumulate rewards, incentives and entries into prize draws or sweepstakes. Incentives may be in the form of points or program/ currency (“ Currency”).  Currency has no monetary value and cannot be redeemed for cash;  Currency may not be auctioned, traded, bartered or sold and is not transferrable upon death, by gift, as part of a domestic relations matter, or otherwise, except by operation of law. Information, official rules and terms and conditions for rewards, incentives and prize draws or sweepstakes may be available in these Terms, on the Website for a , at the beginning or end of a survey, in survey invitations, on the website(s) or webpage(s) for redeeming rewards, incentives, and prizes, and/or may be described in any newsletter or other communication distributed or published by   Service.</span></p>

<p><span>The various types of incentives and rewards   Service may provide are to encourage participation in the  and are not compensation for time spent. Any points or  Currency that is earned or paid to you or any reward that is redeemed by you for participation in the Research or other activity on a  is not calculated based on time spent by you. Similarly, any consideration paid to or points earned by you for participation is not pro-rated on an hourly basis or otherwise.</span></p>

<p><span>B. All points or  Currency posted to a  member’s account expire one (1) year following posting, unless the points or  Currency are forfeited or canceled earlier due to membership or account inactivity or as otherwise set forth in these Terms.  member accounts are not actual bank or financial accounts and do not accrue or accumulate interest of any kind.</span></p>

<p><span>C. Points or  Currency posted in connection with the Applications/Services do not constitute property of the  member, cannot be transferred during or after the  member’s life, by operation of law or otherwise, and have no value until presented by the  member for redemption in accordance with these Terms.</span></p>

<p><span>D. In the event that any points,  Currency, or incentive have been erroneously posted to a  member’s account,   Service may remove them from the  member’s account.</span></p>

<p><span>E. In the event that any points,  Currency, or incentive have been obtained and/or posted to a  member’s account through fraudulent means,   Service will remove them from the  member’s account and the account may be suspended and/or terminated.</span></p>

<p><span>F. Redemption<br>
(1) Points or  Currency will be deducted from the  member's account at the time the redemption request is made.<br>
(2) All redemptions are final, and rewards may not be returned for credit except as otherwise provided in these Terms or as otherwise agreed to in writing by an authorized representative of   Service.<br>
(3) The minimum points or  Currency redemption threshold required to redeem a reward is the equivalent of Fifty United States Dollars ($50). Unless there is a lower redemption option available, if you do not satisfy the foregoing threshold, you will not have a redemption option under   Service’s rewards program.   Service reserves the right to provide reward options with lower minimum redemption thresholds without prior notice to or consent from you.</span></p>

<p><span>G.   Service may modify, alter, delete or add new terms and conditions for its rewards program or the Applications/Services at any time without notice. For   Service this includes, but is not limited to, modifying, altering, adding or deleting point values, redemption levels, conversion ratios, conditions for status, conditions for membership and conditions for earning incentives or rewards, at any time without notice. In addition,   Service may terminate or cease offering any incentive or reward in connection with   Service’s rewards program, at any time without notice.</span></p>

<p><span>H. You may not combine your points or  Currency with points or  Currency belonging to any other member, including, but not limited to, any family member or friend.</span></p>

<p><span>I.   Service make no representations or warranties of any kind, express or implied, regarding any product or service received in connection with   Service’s rewards program, including, but not limited to, any warranty of merchantability or fitness for a particular purpose.   Service is not, and will not be, liable or responsible for the performance of, or for the failure of the performance of, any product or service for which points or  Currency, incentives or rewards are redeemed. In addition,   Service is not and will not be responsible or liable for any cost, damage, accident, delay, injury, loss, expense or inconvenience that may arise in connection with the use of, or defect in, any product or service for which points,  Currency, incentives or rewards are redeemed.   Service will not replace any lost, stolen, misplaced or damaged incentives or rewards.</span></p>

<p><span>J. YOU HEREBY EXPRESSLY ACKNOWLEDGE AND AGREE THAT THE POINTS,  CURRENCY, INCENTIVES OR REWARDS EARNED THROUGH THE APPLICATIONS/SERVICES MAY BE SUBJECT TO TAX, WHICH IS THE SOLE RESPONSIBILITY OF THE  MEMBER.   Service may provide you and/or the appropriate government agency or taxing authority with information related to any payments or incentives you earn in connection with your use of the Applications/Services. You agree to provide   Service with all required information to assist   Service in complying with its reporting or withholding obligations.   Service may withhold any tax from any incentive or reward as required by applicable law.</span></p>

<p><span>K. Every month   Service donates USD $10,000 to American Red Cross. This donation is separate to the incentives you receive for surveys and does not come from your points balance. This does not constitute a donation on your behalf so is not tax deductible for you and is not dependent on the number of surveys in which members participate; it is one way   Service is aiming to give back to the  community.</span></p>

<p><span>L.   Service uses reasonable efforts to ensure that points or  Currency are credited and debited appropriately; however, the  member should review their account to ensure that their account correctly identifies the posted points or  Currency, incentives, or rewards, and reflects all of the appropriate redemption transactions. If you feel that your account was not credited or debited correctly or reflects incorrect redemption transactions, please send an email to helpdesk@opinionl.com. Any email sent to   Service should include the  member’s name, email address and specific information on the subject matter.   Service will use reasonable efforts to investigate the matter and to respond back to the  member promptly.   Service's decision is final and binding.</span></p>

<p><span>M. The suppliers or providers of the products or services offered in connection with   Service’s rewards program and/or the owners or operators of the website(s)/webpage(s) on which redemption transactions occur, may have their own terms and conditions; please review these terms and conditions carefully.</span></p>

<p><span>N. Personal information may have to be collected, processed and/or disclosed in connection with   Service’s rewards program and/or any request to redeem a reward or incentive. By agreeing to these Terms, you hereby agree to the collection, processing and/or disclosure of your personal information for such purpose(s) and all such personal information shall be subject to the terms set forth in   Service’s Privacy Policy. Redemption of Virtual Mastercard® or Visa® may require verification of your identity by the financial institution responsible for issuing your Virtual Mastercard® and Visa®, and that such verification may require you to provide your date of birth, tax identification number, and similar information.</span></p>

<p><span>O. If a  member elects to donate points or  Currency to one of the charities approved by   Service,   Service will donate said points or  Currency to the selected charity. The donation is not made by or on behalf of   Service and   Service does not and will not match any donation. Please note that the donation option is not available on every  owned and/or operated by or on behalf of   Service. Please check the redemption options available for the  to which you belong.</span></p>

<p><span>P. Your daily limit on the redemption of points or  Currency is limited to two (2) redemptions per 24-hour period.</span></p>

<p><span>Q. In the United States,   Service has an obligation to: (i) provide a W-9 tax form to individuals who receive payments (whether via the redemption of points or  Currency or other means) of $700 or more in a tax year; and (ii) file a 1099-Misc form with the United States Internal Revenue Service (“IRS”) for such payments. In addition,   Service will provide you with a completed 1099-Misc form for your tax compliance purposes. As a result, please see the following:<br>
(1) If you have received payments of $899 during a tax year, your account will be suspended (i.e., you will not be able to receive further payments and will not be able to complete or participate in surveys) for the remainder of the applicable tax year unless and until you provide   Service with a completed and verified W-9 form.<br>
(2) If you have received payments of $900 or more during a tax year, your account will be suspended indefinitely (i.e., you will not be able to receive further payments and will not be able to complete or participate in surveys) unless and until you provide   Service with a completed and verified W-9 form. In this case, your account will not be reinstated at the beginning of the next tax year, unless or until you provide   Service with a completed and verified W-9 form.</span></p>

<p><span>If you have any questions, please contact Business@critiquservice.com.</span></p>

<p><span>9. Profile Updates</span></p>

<p><span> members agree to notify   Service promptly of any changes in or to the information contained in their member profile.  members agree to review and update their membership profiles as necessary but no less frequently than once every six (6) months. A  member may update, correct and/or delete information contained in his or her membership profile by: (i) accessing his or her  membership account; or (ii) sending an email to the appropriate  member services team for the appropriate .</span></p>

<p><span>10. Opt-Out Policy</span></p>

<p><span> members may opt out from using the Applications/Services (including, without limitation, from receiving newsletters or communications), at any time, by: (i) following the unsubscribe procedures described on the applicable Website(s) or contained in any email received from   Service; or (ii) sending an email to the  member services team.   Service shall use reasonable efforts to read and respond to each email request within a reasonable period of time after receipt. Upon termination, a  member’s contact information will be removed from any further communication or contact lists. Please allow a few days for the complete removal of contact information from   Service’s communication or contact lists for the applicable ; during which period the member may receive communications which were created or compiled prior to termination. Please see   Service’s Privacy Policy for information on how   Service handles information and data following an unsubscribe, termination or opt-out request (“  Service’s Privacy Policy”).</span></p>

<p><span>11. Links</span></p>

<p><span>In connection with your use of the Applications/Services, you may be able to link or connect voluntarily to websites maintained and/or operated by third parties (“Third Party Websites”).   Service does not endorse any Third Party Website nor any products, services and/or opportunities advertised, offered and/or sold by, through or in connection with any Third Party Website (“Third Party Information”).   Service does not make any representations or warranties regarding Third Party Websites and/or Third Party Information. Please carefully review all policies and terms applicable to Third Party Websites and Third Party Information.</span></p>

<p><span>12. Communications with   Service</span></p>

<p><span>All communications (excluding personal information) and User Content submitted or transmitted by you to   Service, by electronic mail or otherwise, shall be treated as non-confidential and non-proprietary information, unless specifically indicated by you either prior to, or contemporaneously with, the submission or transmission of such communications and User Content. You agree that any such communications and User Content may be used by   Service for any legal reason.</span></p>

<p><span>13. Disclaimer</span></p>

<p><span>THE APPLICATIONS/SERVICES, INCLUDING ALL INFORMATION, SURVEYS, CONTENT, MATERIAL, COMMENTARY AND APPLICATIONS/SERVICES MADE AVAILABLE ON OR THROUGH THE APPLICATIONS/SERVICES, ARE PROVIDED “AS IS”.   Service DOES NOT MAKE ANY REPRESENTATIONS OR WARRANTIES OF ANY KIND WHATSOEVER IN CONNECTION WITH ANY INFORMATION, CONTENT, MATERIAL, COMMENTARY, SURVEYS, PRODUCTS OR SERVICES MADE AVAILABLE ON OR THROUGH THE APPLICATIONS/SERVICES, INCLUDING, BUT NOT LIMITED TO, ANY USER CONTENT. FURTHER,   Service HEREBY DISCLAIMS ANY AND ALL WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.   Service DOES NOT WARRANT THAT THE TOOLS, TECHNOLOGY OR FUNCTIONS CONTAINED IN THE APPLICATIONS/SERVICES OR ANY CONTENT, MATERIAL, COMMENTARY, INFORMATION AND/OR SERVICES CONTAINED THEREIN, WILL BE UNINTERRUPTED OR ERROR FREE, THAT DEFECTS WILL BE CORRECTED, THAT THE SYSTEMS OR THE SERVER(S) THAT SUPPORT THE APPLICATIONS/SERVICES AND MAKE THE APPLICATIONS/SERVICES AVAILABLE WILL BE CORRECTED OR THAT THE APPLICATIONS/SERVICES AND/OR THE SYSTEMS AND/OR THE SERVER(S) THAT SUPPORT THE APPLICATIONS/SERVICES ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS.   Service DOES NOT PROVIDE ACCESS OR CONNECTION TO THE INTERNET AND IS NOT AND SHALL NOT BE RESPONSIBLE OR LIABLE FOR THE ACTIONS OR OMISSIONS OF THIRD PARTIES THAT INTERFERE WITH, LIMIT, RESTRICT OR PREVENT ACCESS OR CONNECTION TO, OR USE OF, THE APPLICATIONS/SERVICES.</span></p>

<p><span>14. Changes</span></p>

<p><span>  Service hereby reserves the right, in   Service’s sole discretion, to make changes to these Terms.   Service encourages you to review these Terms on an ongoing basis.   Service will obtain your consent prior to changes that are of such nature that consent is needed or required. For changes that do not require consent, your continued use of, access to, and/or participation in the Applications/Services does and will to constitute your acceptance of these Terms as amended.</span></p>

<p><span>15. Indemnification</span></p>

<p><span>You agree to indemnify, defend and hold harmless   Service and its parent, affiliated and subsidiary companies and its and their respective members, managers, shareholders, directors, officers, employees and agents from and against any and all claims, liabilities, losses, judgments, awards, fines, penalties and costs and/or expenses of any kind, including, but not limited to, reasonable attorneys’ fees and court costs, arising out of, resulting from or caused, either directly or indirectly, by: (i) your breach or violation of these Terms; and/or (ii) your use of, participation in, and/or access to the Applications/Services.</span></p>

<p><span>16. Limitations of Liability</span></p>

<p><span>EXCEPT TO THE EXTENT PROHIBITED BY APPLICABLE LAWS, YOU ACKNOWLEDGE AND AGREE THAT IN NO EVENT WILL   Service BE LIABLE OR OTHERWISE RESPONSIBLE TO YOU FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL AND/OR PUNITIVE DAMAGES, FOR ANY REASON(S) OR FOR ANY CAUSE(S), REGARDLESS OF WHETHER   Service IS INFORMED OF THE POSSIBILITY THAT SUCH DAMAGES MAY EXIST.</span></p>

<p><span>ANY CLAIM OR CAUSE OF ACTION ARISING OUT OF OR RELATED TO USE OF THE APPLICATIONS/SERVICES AND/OR THESE TERMS MUST BE FILED WITHIN ONE (1) YEAR AFTER SUCH CLAIM OR CAUSE OF ACTION AROSE.</span></p>

<p><span>17. Compliance with Applicable Laws</span></p>

<p><span>You acknowledge and agree that you will comply with all applicable international, national, Federal, state and/or local laws, codes, regulations, rules and/or requirements (“Applicable Laws”) regarding your use of, participation, in, and/or access to the Applications/Services.</span></p>

<p><span>18. Suspension; Termination; De-Activation of  Membership Accounts</span></p>

<p><span>Either party may terminate your membership with a  at any time, with or without cause, for any reason or for no reason, and without liability for the termination.</span></p>

<p><span>In addition to any and all other available remedies,   Service may, without notice, suspend and/or terminate your use of, access to, and/or participation in the Applications/Services if you are in breach or violation of these Terms. If   Service terminates your membership due to your breach or violation of these Terms: (i) you forfeit all rights, title and interest in and/or to all unredeemed rewards, incentives and/or prizes, effective immediately upon termination; (ii) your membership will immediately be cancelled; and (iii) your access to, participation in and use of the Applications/Services (including, but not limited to, participation in survey projects) will immediately cease.</span></p>

<p><span>In the event that a non- member breaches or otherwise violates these Terms, such non- member hereby agrees that: (a) all rights, title and interest in and/or to all unredeemed rewards, incentives and/or prizes (if any), shall be forfeit effective immediately upon termination; and (b) access to, use of, and participation in the Applications/Services will immediately cease.</span></p>

<p><span>In addition,   Service reserves the right to de-activate your  membership account: (a) if your membership account does not remain Active (as defined herein); (b) if   Service receives a hard bounce or delivery failure notice in regards to email communications sent by   Service to your email account; or (c) if   Service receives a “mailbox full” reply notice three (3) times in regards to email communications sent by   Service to your email account. For the purpose of these Terms, “Active” means that you: (i) participate in a survey at least once every six (6) months; or (ii) update your profile or member information at least once every six (6) months.</span></p>

<p><span>In the event of deactivation, termination by you or termination by   Service (other than for your breach or violation of these Terms),   Service shall maintain a record of the posted, unredeemed rewards, incentives and/or prizes and, subject to the applicable minimum redemption thresholds, shall allow you to redeem such rewards, incentives and/or prizes for a period of thirty (30) days following the effective date of termination or deactivation of your account. Termination or deactivation of your membership will not delete or remove any application(s).</span></p>

<p><span>19.   Service Employee</span></p>

<p><span>A. Restriction.   Service employees and their Immediate Family Member(s) (as defined herein) are not eligible to receive any payments, prizes or incentives for using, participating in or accessing the Applications/Services. For the purpose of this Section 19, the term “Immediate Family Member(s)” includes parents, spouses, children or significant others (i.e. girlfriends/boyfriends, domestic partners and spousal equivalents).</span></p>

<p><span>B. Procedures.   Service’s employees may use, access or participate in the Applications/Services only after receiving written permission from their respective manager, and only for the sole purpose of improving   Service’s products and/or services.   Service’s employees must always be honest and report accurate information in connection with using, accessing or participating in the Applications/Services. If altered, false, or untrue information or data must be used, prior consent and approval must be received from   Service’s Chief Executive Officer.</span></p>

<p><span>C. Improper Conduct. Unless authorized pursuant to these Terms or otherwise approved in writing by   Service’s Chief Executive Officer, the violation of the terms of this Section 19 by a   Service employee and/or hos/her Immediate Family Member(s) is a violation of   Service’s standards of conduct and any such violation may subject the employee to discipline, including, but not limited to, termination of employment.</span></p>

<p><span>20. Notices</span></p>

<p><span>A. Notice From You to   Service. Except as otherwise set forth herein or as required by Applicable Laws, all notices to be sent or provided to   Service should: (i) be correctly addressed to the applicable business address, and shall be sufficiently delivered if delivered: (a) by Federal Express, Express Mail or other nationally or internationally recognized overnight courier service (in which case notice shall be effective one (1) business day following dispatch); or (b) by certified mail, return receipt requested, postage prepaid (in which case notice shall be effective six (6) days following deposit in mail); or (ii) be sent via email to the appropriate member services team for the appropriate .</span></p>

<p><span>B. Notice From   Service to You. Except as otherwise required by Applicable Laws, you agree that   Service may provide notices to you: (i) via the e-mail address provided by you to   Service (in which case notice shall be effective one (1) day following the date the e-mail was sent, provided that   Service did not receive an error message stating that delivery of the e-mail was delayed, that the e-mail address was invalid or that the e-mail otherwise could not be delivered); (ii) by certified mail, return receipt requested, postage prepaid addressed to the address provided by you to   Service (in which case notice shall be effective six (6) days following deposit in the mail); or (iii) by posting notices on the applicable Website(s). You agree to check the applicable Website(s) frequently for notices and to keep your personal information up-to-date.</span></p>

<p><span>21. Severability</span></p>

<p><span>If any term or provision of these Terms shall be held or declared to be invalid or unenforceable for any reason by any court of competent jurisdiction, such term or provision shall be deemed null and void and shall not affect the application and/or interpretation of these Terms. The remaining terms or provisions of these Terms shall continue in full force and effect, as if the invalid or unenforceable term or provision was not a part of these Terms.</span></p>

<p><span>22. Arbitration Agreement (United States only)</span></p>

<p><span>All claims and disputes (excluding claims for injunctive or other equitable relief as set forth below) in connection with the Terms, use of any product or service provided by   Service, or related to the processing of personal data, that cannot be resolved informally or on an individual basis in small claims court shall be resolved by binding arbitration on an individual basis under the terms of this Section 22 (this “Arbitration Agreement”). Unless otherwise agreed, all arbitration proceedings will be held in English. This Arbitration Agreement applies to you and   Service, and to any subsidiaries, affiliates, agents, employees, predecessors in interest, successors, and assigns, as well as all authorized or unauthorized users or beneficiaries of services or goods provided under the Terms.</span></p>

<p><span>Before either party may seek arbitration, the party must first send to the other party a written Notice of Dispute (“Notice”) describing the nature and basis of the claim or dispute, and the requested relief. A Notice to   Service should be sent to: 4 Research Drive, Suite 300, Shelton, Connecticut 06484 USA; ATTN: Arbitration Notice. After the Notice is received, you and   Service may attempt to resolve the claim or dispute informally. If you and   Service do not resolve the claim or dispute within thirty (30) days after the Notice is received, either party may begin an arbitration proceeding. The amount of any settlement offer made by any party may not be disclosed to the arbitrator until after the arbitrator has determined the amount of the award, if any, to which either party is entitled.</span></p>

<p><span>Arbitration shall be initiated through the Judicial Arbitration and Mediation Services, Inc. (“JAMS”), an established alternative dispute resolution provider (“ADR Provider”) that offers arbitration as set forth in this section. If JAMS is not available to arbitrate, the parties shall agree to select an alternative ADR Provider. The rules of the ADR Provider shall govern all aspects of the arbitration, including but not limited to the method of initiating and/or demanding arbitration, except to the extent such rules are in conflict with the Terms. The JAMS Streamlined Arbitration Rules (the “JAMS Rules”) governing the arbitration are available online at https://www.jamsadr.com/. The arbitration shall be conducted by a single, neutral arbitrator. Any claims or disputes where the total amount of the award sought is less than Ten Thousand U.S. Dollars (US $10,000.00) may be resolved through binding non-appearance-based arbitration, at the option of the party seeking relief. For claims or disputes where the total amount of the award sought is Ten Thousand U.S. Dollars (US $10,000.00) or more, the right to a hearing will be determined by the Arbitration Rules. Any hearing will be held in a location within 100 miles of your residence, unless you reside outside of the United States, and unless the parties agree otherwise. If you reside outside of the U.S., the arbitrator shall give the parties reasonable notice of the date, time and place of any oral hearings. Any judgment on the award rendered by the arbitrator may be entered in any court of competent jurisdiction. Each party shall bear its own costs (including attorney’s fees) and disbursements arising out of the arbitration and shall pay an equal share of the fees and costs of the ADR Provider.</span></p>

<p><span>If non-appearance-based arbitration is elected, the arbitration shall be conducted by telephone, online and/or based solely on written submissions; the specific manner shall be chosen by the party initiating the arbitration. The arbitration shall not involve any personal appearance by the parties or witnesses unless otherwise agreed by the parties.</span></p>

<p><span>If you or   Service pursue arbitration, the arbitration action must be initiated and/or demanded within the statute of limitations (i.e., the legal deadline for filing a claim) and within any deadline imposed under the JAMS Rules for the pertinent claim.</span></p>

<p><span>If arbitration is initiated, the arbitrator will decide the rights and liabilities, if any, of you and   Service, and the dispute will not be consolidated with any other matters or joined with any other cases or parties. The arbitrator shall have the authority to grant motions dispositive of all or part of any claim (including any claim regarding the enforceability of this Arbitration Agreement or any unconscionability in connection with these Terms). The arbitrator shall have the authority to award monetary damages, and to grant any non-monetary remedy or relief available to an individual under applicable law, the JAMS Rules, and the Terms. The arbitrator shall issue a written award and statement of decision describing the essential findings and conclusions on which the award is based, including the calculation of any damages awarded. The arbitrator has the same authority to award relief on an individual basis that a judge in a court of law would have. The award of the arbitrator is final and binding upon you and   Service.</span></p>

<p><span>THE PARTIES HEREBY WAIVE THEIR CONSTITUTIONAL AND STATUTORY RIGHTS TO GO TO COURT AND HAVE A TRIAL IN FRONT OF A JUDGE OR A JURY, instead electing that all claims and disputes shall be resolved by arbitration under this Arbitration Agreement. Arbitration procedures are typically more limited, more efficient and less costly than rules applicable in a court and are subject to very limited review by a court. In the event any litigation should arise between you and   Service in any state or federal court in a suit to vacate or enforce an arbitration award or otherwise, YOU AND THE COMPANY WAIVE ALL RIGHTS TO A JURY TRIAL, instead electing that the dispute be resolved by a judge.</span></p>

<p><span>ALL CLAIMS AND DISPUTES WITHIN THE SCOPE OF THIS ARBITRATION AGREEMENT MUST BE ARBITRATED OR LITIGATED ON AN INDIVIDUAL BASIS AND NOT ON A CLASS BASIS, AND CLAIMS OF MORE THAN ONE CUSTOMER OR USER CANNOT BE ARBITRATED OR LITIGATED JOINTLY OR CONSOLIDATED WITH THOSE OF ANY OTHER CUSTOMER OR USER.</span></p>

<p><span>All aspects of the arbitration proceeding, including but not limited to the award of the arbitrator and compliance therewith, shall be strictly confidential. The parties agree to maintain confidentiality unless otherwise required by law. This paragraph shall not prevent a party from submitting to a court of law any information necessary to enforce this Agreement, to enforce an arbitration award, or to seek injunctive or equitable relief. If any part or parts of this Arbitration Agreement are found under the law to be invalid or unenforceable with regards to any particular subject matter by a court of competent jurisdiction, then such specific part or parts shall be of no force and effect with regard to such specific subject matter and shall be severed and the remainder of the Agreement shall continue in full force and effect.</span></p>

<p><span>Any or all of the rights and limitations set forth in this Arbitration Agreement may be waived by the party against whom the claim is asserted. Such waiver shall not waive or affect any other portion of this Arbitration Agreement.</span></p>

<p><span>This Arbitration Agreement will survive the termination of your relationship with   Service.</span></p>

<p><span>Notwithstanding the foregoing, either you or   Service may bring an individual action in small claims court.</span></p>

<p><span>Notwithstanding the foregoing, either party may seek emergency equitable relief before a state or federal court in order to maintain the status quo pending arbitration. A request for interim measures shall not be deemed a waiver of any other rights or obligations under this Arbitration Agreement.</span></p>

<p><span>Notwithstanding the foregoing, claims of defamation, violation of the Computer Fraud and Abuse Act, and infringement or misappropriation of the other party’s patent, copyright, trademark or trade secrets shall not be subject to this Arbitration Agreement.</span></p>

<p><span>In any circumstances where the foregoing Arbitration Agreement permits the parties to litigate in court, the parties hereby agree to submit to the personal jurisdiction of the courts located within Fairfield County, Connecticut, USA for such purpose.</span></p>

<p><span>23. Governing Laws; Jurisdiction and Venue</span></p>

<p><span>These Terms and your access to, use of or participation in the Applications/Services shall be governed by and construed in accordance with the laws of the state of Connecticut, USA, without regard to any portion of any choice of law principles (whether those of Connecticut or any other jurisdiction) that might provide for application of a different jurisdiction’s laws. All claims or disputes arising in connection with these Terms and/or your access to, use of or participation in the Applications/Services shall be subject to the exclusive jurisdiction of the state or Federal courts located in Fairfield County, Connecticut, USA.</span></p>

<p><span>24. Miscellaneous Terms</span></p>

<p><span>The headings contained in these Terms are for reference only and shall have no effect on the interpretation and/or application of these Terms.   Service’s failure to enforce a breach by you of these Terms shall not waive or release you from such breach and shall not waive, release or prevent   Service from enforcing any subsequent breach by you of these Terms. These Terms and any rules, terms or policies referenced herein or incorporated herein, and any -specific requirements, represent the entire understanding and agreement between   Service and you with respect to the subject matter hereof.</span></p>

<p><span>Last updated: November 29, 2021</span><br>
&nbsp;</p>
    <style>/* l css */
  .promo h2 {
    color:#231F20;
  }
.promoFooter-content h3 {
font-size: 22px;
}
  @media only screen and (min-width:1024px){
  .hero .container, .hero .hero-desc {
    width: 1024px;
  }
  }

.button, .header .link {text-decoration:none!important;}
@media only screen and (min-width:831px) {
  .promo-top-bar-section {
    width: 180px;
    border-top: 5px solid #17436c;
    display: block;
    margin:20px 0;
    max-width:190px;
  }
  }
  .header-col-block {
    color:#231F20;
    font-weight:700!important;
  }
  
  .header .link .fa.fa-star-o, .header .link [icon] {
    fill:#231F20;
  }

.promoFooter-promo , .btn, .button{
border-radius: 0px;
}

.badge-details .tier-row .tier-button.selected {
border-bottom: 5px solid #17436c!important;
}
</style><style type="text/css">#templink {
    display:none;
  }
</style></div>
  </div>

 <?php include 'components/footer.php';?>

    </div>
            <!--Back To Start-->
            <a href="#" class="back-to-top">
            <i class="icofont-simple-up"></i>
        </a>
        <!--Back To End-->
<?php include 'components/js.php';?>

</body>


</html>